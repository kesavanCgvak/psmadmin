<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use App\Models\Company;
use App\Models\User;
use App\Models\CompanyRating;
use App\Models\CompanyBlock;
use App\Models\CompanyProviderBlock;
use App\Models\JobRating;
use App\Support\DefaultImagePath;



class CompanyController extends Controller
{
    /**
     * Get company info
     */
    public function getInfo()
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found'
                ], 404);
            }

            $companyDetails = [
                'name' => $company->name,
                'description' => $company->description,
                'logo' => DefaultImagePath::companyLogo($company->logo),
                'logo_available_for_promotion' => (bool) $company->logo_available_for_promotion,
                'logo_promotion_consent_at' => $company->logo_promotion_consent_at?->toIso8601String(),
                'logo_promotion_admin_enabled' => (bool) $company->logo_promotion_admin_enabled,
                'logo_promotion_active' => $company->isLogoPromotionActive(),
                'image1' => $company->image1,
                'image2' => $company->image2,
                'image3' => $company->image3,
            ];

            return response()->json([
                'success' => true,
                'data' => $companyDetails
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error fetching company info', [
                'error' => $e->getMessage()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to fetch company info'
            ], 500);
        }
    }

    /**
     * Update company basic info
     */
    public function updateInfo(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json(['success' => false, 'message' => 'Company not found'], 404);
            }

            $validator = Validator::make($request->all(), [
                'name' => 'sometimes|string|max:255',
                'website' => 'sometimes|url',
                'phone' => 'sometimes|string|max:20',
            ]);

            if ($validator->fails()) {
                return response()->json(['success' => false, 'errors' => $validator->errors()], 422);
            }

            $company->update($request->only(['name', 'website', 'phone']));

            return response()->json(['success' => true, 'message' => 'Company info updated successfully'], 200);
        } catch (\Exception $e) {
            Log::error('Error updating company info', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'message' => 'Unable to update company info'], 500);
        }
    }

    /**
     * Get company preferences
     */
    public function getPreferences()
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found',
                ], 404);
            }
            $preferences = [
                'currency_id' => $company->currency_id,
                'date_format_id' => $company->date_format_id,
                'pricing_scheme_id' => $company->pricing_scheme_id,
                'hide_from_gear_finder' => $company->hide_from_gear_finder,
                'rental_software_id' => $company->rental_software_id,
            ];

            return response()->json([
                'success' => true,
                'preferences' => $preferences,
            ], 200);

        } catch (TokenExpiredException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Token has expired'
            ], 401);
        } catch (TokenInvalidException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid token'
            ], 401);
        } catch (JWTException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Token not provided'
            ], 401);
        } catch (\Exception $e) {
            Log::error('Error fetching preferences: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'Unable to fetch preferences',
            ], 500);
        }
    }

    /**
     * Update company preferences
     */
    public function updatePreferences(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found',
                ], 404);
            }

            // Validate payload
            $validated = $request->validate([
                'currency_id' => 'nullable|integer|exists:currencies,id',
                'date_format_id' => 'nullable|integer|exists:date_formats,id',
                'pricing_scheme_id' => 'nullable|integer|exists:pricing_schemes,id',
                'rental_software_id' => 'nullable|integer|exists:rental_softwares,id',
            ]);

            // Update only provided fields
            $company->update($validated);

            // Reload relationships
            $company->load(['currency', 'rentalSoftware', 'dateFormat', 'pricingScheme']);

            // Format response with full objects
            $preferences = [];

            // Currency object
            if ($company->currency) {
                $preferences['currency'] = [
                    'id' => $company->currency->id,
                    'name' => $company->currency->name,
                    'code' => $company->currency->code,
                    'symbol' => $company->currency->symbol,
                ];
            }

            // Rental Software object
            if ($company->rentalSoftware) {
                $preferences['rental_software'] = [
                    'id' => $company->rentalSoftware->id,
                    'name' => $company->rentalSoftware->name,
                    'version' => $company->rentalSoftware->version ?? '',
                ];
            }

            // Date Format string
            if ($company->dateFormat) {
                $preferences['date_format'] = $company->dateFormat->format;
            }

            // Pricing Scheme string (using name)
            if ($company->pricingScheme) {
                $preferences['pricing_scheme'] = $company->pricingScheme->name;
            }

            return response()->json([
                'success' => true,
                'message' => 'Preferences updated successfully.',
                'preferences' => $preferences,
            ], 200);

        } catch (TokenExpiredException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Token has expired'
            ], 401);
        } catch (TokenInvalidException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid token'
            ], 401);
        } catch (JWTException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Token not provided'
            ], 401);
        } catch (\Exception $e) {
            Log::error('Error updating preferences: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'Unable to update preferences',
            ], 500);
        }
    }


    /**
     * Update default contact
     */
    public function updateDefaultContact(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            $validator = Validator::make($request->all(), [
                'contact_id' => 'required|exists:users,id'
            ]);

            if ($validator->fails()) {
                return response()->json(['success' => false, 'errors' => $validator->errors()], 422);
            }

            //Update default contact id in companies table
            $company->default_contact_id = $request->contact_id;
            $company->save();

            //Reset all company users' default flag to 0
            User::where('company_id', $company->id)
                ->update(['is_company_default_contact' => 0]);

            //Set the chosen user as default contact
            User::where('id', $request->contact_id)
                ->update(['is_company_default_contact' => 1]);

            return response()->json([
                'success' => true,
                'message' => 'Default contact updated successfully'
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error updating default contact', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to update default contact'
            ], 500);
        }
    }

    /**
     * Update Gear Finder visibility
     */
    public function updateGearFinderVisibility(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            $validated = $request->validate([
                'hide_from_gear_finder' => 'required|boolean',
            ]);

            $company->hide_from_gear_finder = $validated['hide_from_gear_finder'];
            $company->save();

            $message = $validated['hide_from_gear_finder']
                ? 'Company hidden from Gear Finder.'
                : 'Company visible in Gear Finder.';

            return response()->json([
                'success' => true,
                'message' => $message,
            ], 200);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error updating Gear Finder visibility', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to update Gear Finder visibility',
            ], 500);
        }
    }

    /**
     * Update promotional logo consent (company agrees to logo use in marketing materials).
     */
    public function updateLogoPromotionConsent(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found',
                ], 404);
            }

            if (!$company->isProviderCompany()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Promotional logo consent is only available for provider companies.',
                ], 403);
            }

            $validated = $request->validate([
                'logo_available_for_promotion' => 'required|boolean',
            ]);

            $enabled = (bool) $validated['logo_available_for_promotion'];

            if ($enabled && empty($company->logo)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Upload a company logo before allowing promotional use.',
                ], 422);
            }

            $company->applyLogoPromotionConsent($enabled);

            $message = $enabled
                ? 'Your company logo is now available for promotional materials.'
                : 'Your company logo is no longer available for promotional materials.';

            return response()->json([
                'success' => true,
                'message' => $message,
                'logo_available_for_promotion' => (bool) $company->logo_available_for_promotion,
                'logo_promotion_consent_at' => $company->logo_promotion_consent_at?->toIso8601String(),
                'logo_promotion_admin_enabled' => (bool) $company->logo_promotion_admin_enabled,
                'logo_promotion_active' => $company->isLogoPromotionActive(),
            ], 200);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            Log::error('Error updating logo promotion consent', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to update logo promotion consent',
            ], 500);
        }
    }

    /**
     * Get default contact
     */
    public function getDefaultContact()
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            $contact = $company->defaultContactProfile ?? null;

            if (!$contact) {
                return response()->json([
                    'success' => false,
                    'message' => 'Default contact not found'
                ], 404);
            }

            $contactData = [
                'name' => $contact->full_name,
                'email' => $contact->email,
                'mobile' => $contact->mobile,
            ];

            return response()->json([
                'success' => true,
                'contact' => $contactData
            ], 200);

        } catch (TokenExpiredException $e) {
            return response()->json(['success' => false, 'message' => 'Token has expired'], 401);
        } catch (TokenInvalidException $e) {
            return response()->json(['success' => false, 'message' => 'Invalid token'], 401);
        } catch (JWTException $e) {
            return response()->json(['success' => false, 'message' => 'Token not provided'], 401);
        } catch (\Exception $e) {
            Log::error('Error fetching default contact', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'message' => 'Unable to fetch default contact'], 500);
        }
    }

    /**
     * Update company extra info
     */
    public function updateCompanyInfo(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            $company->update($request->all());

            return response()->json(['success' => true, 'message' => 'Company info updated'], 200);
        } catch (\Exception $e) {
            Log::error('Error updating company info', ['error' => $e->getMessage()]);
            return response()->json(['success' => false, 'message' => 'Unable to update company info'], 500);
        }
    }

    /**
     * Upload company image (logo or image1/image2/image3)
     * Auto-deletes old image if exists
     */
    public function uploadImage(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            $request->validate([
                'type' => 'required|in:logo,image1,image2,image3',
                'image' => 'required|image|mimes:jpeg,png,jpg|max:2048'
            ]);

            // Define upload folder
            $uploadPath = public_path('images/company_images');

            // Ensure folder exists
            if (!file_exists($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }

            // Delete old image if exists
            if ($company->{$request->type}) {
                $oldImage = public_path($company->{$request->type});
                if (file_exists($oldImage)) {
                    unlink($oldImage);
                }
            }

            // Generate unique filename
            $filename = time() . '_' . uniqid() . '.' . $request->file('image')->getClientOriginalExtension();

            // Move uploaded file
            $request->file('image')->move($uploadPath, $filename);

            // Save relative path in DB
            $relativePath = 'images/company_images/' . $filename;

            $company->update([
                $request->type => $relativePath
            ]);

            if ($request->type === 'logo' && $company->isProviderCompany()) {
                $company->applyLogoPromotionConsent(true);
            }

            return response()->json([
                'success' => true,
                'message' => ucfirst($request->type) . ' uploaded successfully',
                'path' => $relativePath,
                'url' => url($relativePath),
                'logo_available_for_promotion' => (bool) $company->logo_available_for_promotion,
                'logo_promotion_consent_at' => $company->logo_promotion_consent_at?->toIso8601String(),
                'logo_promotion_admin_enabled' => (bool) $company->logo_promotion_admin_enabled,
                'logo_promotion_active' => $company->isLogoPromotionActive(),
            ], 201);

        } catch (\Exception $e) {
            Log::error('Error uploading company image', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to upload company image'
            ], 500);
        }
    }

    /**
     * Get company images (logo + 3 images)
     */
    public function getImages()
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            $images = [
                'logo' => DefaultImagePath::companyLogoPayload($company->logo),
                'logo_available_for_promotion' => (bool) $company->logo_available_for_promotion,
                'logo_promotion_consent_at' => $company->logo_promotion_consent_at?->toIso8601String(),
                'logo_promotion_admin_enabled' => (bool) $company->logo_promotion_admin_enabled,
                'logo_promotion_active' => $company->isLogoPromotionActive(),
                'image1' => $company->image1 ? [
                    'path' => $company->image1,
                    'url' => url($company->image1)
                ] : null,
                'image2' => $company->image2 ? [
                    'path' => $company->image2,
                    'url' => url($company->image2)
                ] : null,
                'image3' => $company->image3 ? [
                    'path' => $company->image3,
                    'url' => url($company->image3)
                ] : null,
            ];

            return response()->json([
                'success' => true,
                'images' => $images
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error fetching company images', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to fetch company images'
            ], 500);
        }
    }

    /**
     * Delete company image (logo or image1/image2/image3)
     * Auto-deletes file from public/images/company_images
     */
    public function deleteImage(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            $request->validate([
                'type' => 'required|in:logo,image1,image2,image3'
            ]);

            $type = $request->type;

            if ($company->{$type}) {
                $filePath = public_path($company->{$type});

                // Delete file if exists
                if (file_exists($filePath)) {
                    unlink($filePath);
                }

                // Remove reference from DB
                $company->update([$type => null]);

                if ($type === 'logo') {
                    $company->revokeLogoPromotionConsent();
                }
            }

            return response()->json([
                'success' => true,
                'message' => ucfirst($type) . ' deleted successfully'
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error deleting company image', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to delete company image'
            ], 500);
        }
    }


    /**
     * Get company address
     */
    public function getAddress()
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found'
                ], 404);
            }

            $address = [
                'region' => $company->region_id,
                'country' => $company->country_id,
                'city' => $company->city_id,
                'state' => $company->state_id,
                'address_line_1' => $company->address_line_1,
                'address_line_2' => $company->address_line_2,
                'postal_code' => $company->postal_code,
            ];

            return response()->json([
                'success' => true,
                'address' => $address
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error fetching address', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to fetch address'
            ], 500);
        }
    }

    /**
     * Update company address
     */
    public function updateAddress(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found'
                ], 404);
            }

            $validator = Validator::make($request->all(), [
                // 'region' => 'nullable|integer|exists:regions,id',
                'country_id' => 'nullable|integer|exists:countries,id',
                'city_id' => 'nullable|integer|exists:cities,id',
                'state_id' => 'nullable|integer|exists:states_provinces,id',
                'address_line_1' => 'nullable|string|max:255',
                'address_line_2' => 'nullable|string|max:255',
                'postal_code' => 'nullable|string|max:20',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors()
                ], 422);
            }

            $company->update([
                // 'region_id' => $request->region,
                'country_id' => $request->country_id,
                'city_id' => $request->city_id,
                'state_id' => $request->state_id,
                'address_line_1' => $request->address_line_1,
                'address_line_2' => $request->address_line_2,
                'postal_code' => $request->postal_code,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Address updated successfully'
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error updating address', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to update address'
            ], 500);
        }
    }

    /**
     * Get search priority
     */
    public function getSearchPriority()
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found'
                ], 404);
            }

            return response()->json([
                'success' => true,
                'search_priority' => $company->search_priority
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error fetching search priority', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to fetch search priority'
            ], 500);
        }
    }

    /**
     * Update search priority
     */
    public function updateSearchPriority(Request $request)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $company = $user->company;

            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found'
                ], 404);
            }

            $validator = Validator::make($request->all(), [
                'search_priority' => 'required|integer|min:1|max:9999'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors()
                ], 422);
            }

            $company->update([
                'search_priority' => $request->search_priority
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Search priority updated successfully',
                'search_priority' => $company->search_priority
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error updating search priority', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to update search priority'
            ], 500);
        }
    }

    /**
     * Search for companies offering specific products near a city.
     * Supports multiple products, includes distance, available quantity, and currency.
     */
    public function searchCompanies(Request $request)
    {
        try {
            $user = auth()->user();
            if (!$user) {
                return response()->json(['message' => 'Unauthorized'], 401);
            }

            // ✅ Validate request
            $validated = $request->validate([
                'products' => 'required|array|min:1',
                'products.*.product_id' => 'required|integer|exists:inventory_master,id',
                'products.*.quantity' => 'required|numeric|min:1',
                'city_id' => 'required|integer|exists:cities,id',
                'country' => 'nullable|integer|exists:countries,id',
                'distance' => 'nullable|numeric|min:1',
            ]);

            // ✅ Get city coordinates
            $city = DB::table('cities')->where('id', $validated['city_id'])->first();
            if (!$city || !$city->latitude || !$city->longitude) {
                return response()->json(['error' => 'City latitude and longitude are required'], 400);
            }

            $cityLat = $city->latitude;
            $cityLng = $city->longitude;
            $radius = $validated['distance'] ?? 50; // default 50 km

            // ✅ Extract product IDs & quantities
            $productData = collect($validated['products']);
            $productIds = $productData->pluck('product_id')->toArray();
            $requestedQuantities = $productData->pluck('quantity', 'product_id')->toArray();

            // ✅ Blocked companies for the current user
            $blockedCompanyIds = DB::table('company_blocks')
                ->where('user_id', $user->id)
                ->pluck('company_id')
                ->toArray();

            $distanceExpression = "(
                COALESCE(
                    6371 * acos(
                        LEAST(
                            1.0,
                            cos(radians($cityLat))
                            * cos(radians(companies.latitude))
                            * cos(radians(companies.longitude) - radians($cityLng))
                            + sin(radians($cityLat))
                            * sin(radians(companies.latitude))
                        )
                    ), 0
                )
            )";

            // ✅ Main query with joins + geolocation (exclude admin-blocked companies)
            $query = Company::with(['defaultContactProfile'])
                ->whereNull('blocked_by_admin_at')
                ->join('company_inventory', function ($join) use ($productIds) {
                    $join->on('companies.id', '=', 'company_inventory.company_id')
                        ->whereIn('company_inventory.product_id', $productIds);
                })
                ->join('inventory_master', 'inventory_master.id', '=', 'company_inventory.product_id')
                ->leftJoin('brands', 'brands.id', '=', 'inventory_master.brand_id')
                ->join('currencies', 'currencies.id', '=', 'companies.currency_id')
                ->leftJoin('rental_softwares', 'rental_softwares.id', '=', 'companies.rental_software_id')
                // 🆕 Join city, state, and country tables for geolocation details
                ->leftJoin('cities', 'cities.id', '=', 'companies.city_id')
                ->leftJoin('states_provinces', 'states_provinces.id', '=', 'companies.state_id')
                ->leftJoin('countries', 'countries.id', '=', 'companies.country_id')
                ->select(
                    'companies.id as company_id',
                    'companies.name as company_name',
                    'companies.logo as company_logo',
                    'companies.latitude as company_lat',
                    'companies.longitude as company_lng',
                    'companies.rating as company_rating',
                    'companies.rating_override as company_rating_override',
                    'companies.default_contact_id',
                    'companies.city_id',
                    'company_inventory.id as equipment_id',
                    'company_inventory.product_id',
                    'company_inventory.quantity',
                    // 'inventory_master.model as product_name',
                    DB::raw("CONCAT(COALESCE(brands.name, ''),
                        CASE WHEN brands.name IS NOT NULL THEN ' - ' ELSE '' END,
                        inventory_master.model) as product_name"),
                    'inventory_master.psm_code',
                    'company_inventory.rental_price',
                    'company_inventory.software_code',
                    'currencies.id as currency_id',
                    'currencies.name as currency_name',
                    'currencies.code as currency_code',
                    'currencies.symbol as currency_symbol',
                    'rental_softwares.name as rental_software_code',
                    // 🆕 Geolocation fields
                    'cities.name as city_name',
                    'states_provinces.name as state_name',
                    'countries.name as country_name',
                    DB::raw("$distanceExpression as distance")
                )
                ->where('companies.id', '!=', $user->company_id)
                ->where('companies.hide_from_gear_finder', 0);

            // ✅ Exclude blocked companies
            if (!empty($blockedCompanyIds)) {
                $query->whereNotIn('companies.id', $blockedCompanyIds);
            }

            // ✅ Country filter
            if (!empty($validated['country'])) {
                $query->where('companies.country_id', $validated['country']);
            }

            // ✅ Distance or same-city fallback
            $query->where(function ($distanceQuery) use ($distanceExpression, $radius, $validated) {
                $distanceQuery->whereRaw("$distanceExpression <= ?", [$radius])
                    ->orWhere('companies.city_id', $validated['city_id']);
            })->orderBy('distance');

            $results = $query->get();

            if ($results->isEmpty()) {
                return response()->json(['message' => 'No companies found matching your filters.'], 200);
            }

            // ✅ Company IDs for rating lookups
            $companyIds = $results->pluck('company_id')->unique()->values();

            // ✅ Average rating and count per company: job_ratings (renter→provider) then company_ratings fallback
            $jobRatingsData = DB::table('job_ratings')
                ->join('supply_jobs', 'job_ratings.supply_job_id', '=', 'supply_jobs.id')
                ->whereIn('supply_jobs.provider_id', $companyIds)
                ->whereNotNull('job_ratings.rated_at')
                ->groupBy('supply_jobs.provider_id')
                ->select(
                    'supply_jobs.provider_id',
                    DB::raw('AVG(job_ratings.rating) as avg_rating'),
                    DB::raw('COUNT(job_ratings.id) as rating_count')
                )
                ->get()
                ->keyBy('provider_id');
            $jobRatingsAvg = $jobRatingsData->pluck('avg_rating', 'provider_id')->toArray();
            $jobRatingsCount = $jobRatingsData->pluck('rating_count', 'provider_id')->toArray();

            $companyRatingsData = DB::table('company_ratings')
                ->whereIn('company_id', $companyIds)
                ->groupBy('company_id')
                ->select(
                    'company_id',
                    DB::raw('AVG(rating) as avg_rating'),
                    DB::raw('COUNT(id) as rating_count')
                )
                ->get()
                ->keyBy('company_id');
            $companyRatingsAvg = $companyRatingsData->pluck('avg_rating', 'company_id')->toArray();
            $companyRatingsCount = $companyRatingsData->pluck('rating_count', 'company_id')->toArray();

            // ✅ Group results by company
            $companies = $results->groupBy('company_id')->map(function ($items) use ($requestedQuantities, $jobRatingsAvg, $jobRatingsCount, $companyRatingsAvg, $companyRatingsCount) {
                $first = $items->first();
                $cid = $first->company_id;
                $avgRating = 0;
                $ratingCount = 0;
                if (isset($jobRatingsAvg[$cid])) {
                    $avgRating = round((float) $jobRatingsAvg[$cid], 1);
                    $ratingCount = (int) ($jobRatingsCount[$cid] ?? 0);
                } elseif (isset($companyRatingsAvg[$cid])) {
                    $avgRating = round((float) $companyRatingsAvg[$cid], 1);
                    $ratingCount = (int) ($companyRatingsCount[$cid] ?? 0);
                }
                $displayAverageRating = $first->company_rating_override !== null
                    ? round((float) $first->company_rating_override, 1)
                    : $avgRating;

                return [
                    'id' => $cid,
                    'name' => $first->company_name,
                    'company_logo' => DefaultImagePath::companyLogo($first->company_logo),
                    'rating' => $first->company_rating,
                    // If admin override exists, use it for the displayed overall rating.
                    'average_rating' => $displayAverageRating,
                    'user_average_rating' => $avgRating,
                    'rating_count' => $ratingCount,
                    'rental_software_code' => $first->rental_software_code,
                    'distance' => round($first->distance, 2),
                    'location' => [ // 🆕 Added location block
                        'country' => $first->country_name,
                        'state' => $first->state_name,
                        'city' => $first->city_name,
                    ],
                    'currency' => [
                        'id' => $first->currency_id,
                        'name' => $first->currency_name,
                        'code' => $first->currency_code,
                        'symbol' => $first->currency_symbol,
                    ],
                    'products' => $items->map(function ($item) use ($requestedQuantities) {
                        $requestedQty = $requestedQuantities[$item->product_id] ?? 0;
                        $availableQty = $item->quantity ?? 0;

                        return [
                            'equipment_id' => (int) $item->equipment_id,
                            'product_id' => $item->product_id,
                            'product_name' => $item->product_name,
                            'requested_quantity' => (int) $requestedQty,
                            'available_quantity' => (int) $availableQty,
                            'price' => number_format($item->rental_price, 2, '.', ''),
                            'software_code' => $item->software_code,
                            'psm_code' => $item->psm_code,
                        ];
                    })->values(),
                    'default_contact_profile' => $first->defaultContactProfile
                        ? [
                            'name' => $first->defaultContactProfile->full_name,
                            'email' => $first->defaultContactProfile->email,
                            'mobile' => $first->defaultContactProfile->mobile,
                        ]
                        : null,
                ];
            })->values();

            return response()->json([
                'success' => true,
                'data' => $companies
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error searching companies: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json([
                'message' => 'Something went wrong. Please try again later.',
            ], 500);
        }
    }

    /**
     * Search companies with filters and distance radius
     */
    public function searchCompaniesOld(Request $request)
    {
        try {
            $user = auth()->user();

            if (!$user) {
                return response()->json(['message' => 'Unauthorized'], 401);
            }

            // Validate input
            $request->validate([
                'product_id' => 'required',
                'city_id' => 'required|integer|exists:cities,id',
                'country' => 'nullable|integer|exists:countries,id',
                'distance' => 'nullable|numeric|min:1',
            ]);

            // Get city lat/long from DB
            $city = DB::table('cities')->where('id', $request->city_id)->first();
            if (!$city || !$city->latitude || !$city->longitude) {
                return response()->json(['error' => 'City latitude and longitude are required'], 400);
            }

            $city_lat = $city->latitude;
            $city_lng = $city->longitude;
            $radius = $request->distance ?? 50; // default to 50 km if not given

            // Support multiple product IDs
            $productIds = explode(',', $request->product_id);

            // Main query with SQL-based distance calculation (exclude admin-blocked companies)
            $query = Company::where('hide_from_gear_finder', 0)
                ->whereNull('blocked_by_admin_at')
                ->with(['defaultContactProfile'])
                ->join('company_inventory', function ($join) use ($productIds) {
                    $join->on('companies.id', '=', 'company_inventory.company_id')
                        ->whereIn('company_inventory.product_id', $productIds);
                })
                ->join('inventory_master', 'inventory_master.id', '=', 'company_inventory.product_id')
                ->select(
                    'companies.id as company_id',
                    'companies.name as company_name',
                    'companies.latitude as company_lat',
                    'companies.longitude as company_lng',
                    'companies.rating as company_rating',
                    'companies.default_contact_id',
                    'company_inventory.product_id',
                    'inventory_master.model as product_name',
                    'company_inventory.rental_price',
                    'company_inventory.software_code',
                    DB::raw("(
                    6371 * acos(
                        cos(radians($city_lat))
                        * cos(radians(companies.latitude))
                        * cos(radians(companies.longitude) - radians($city_lng))
                        + sin(radians($city_lat))
                        * sin(radians(companies.latitude))
                    )
                ) as distance")
                )
                ->having('distance', '<=', $radius)
                ->orderBy('distance');

            if ($request->filled('country')) {
                $query->where('companies.country_id', $request->country);
            }

            $results = $query->get();

            if ($results->isEmpty()) {
                return response()->json(['message' => 'No companies found matching your filters.'], 200);
            }

            // Group results by company
            $companies = $results->groupBy('company_id')->map(function ($items) {
                $first = $items->first();

                return [
                    'id' => $first->company_id,
                    'name' => $first->company_name,
                    'rating' => $first->company_rating,
                    'products' => $items->map(function ($item) {
                        return [
                            'product_id' => $item->product_id,
                            'product_name' => $item->product_name,
                            'price' => number_format($item->rental_price, 2, '.', ''),
                            'software_code' => $item->software_code,
                        ];
                    })->values(),
                    'distance' => round($first->distance, 2), // from SQL
                    'default_contact_profile' => $first->defaultContactProfile
                        ? [
                            'name' => $first->defaultContactProfile->full_name,
                            'email' => $first->defaultContactProfile->email,
                            'mobile' => $first->defaultContactProfile->mobile,
                        ]
                        : null,
                ];
            })->values();

            return response()->json([
                'success' => true,
                'data' => $companies
            ], 200);

        } catch (\Exception $e) {
            Log::error('Error searching companies for product: ' . $e->getMessage(), [
                'error' => $e->getTraceAsString()
            ]);
            return response()->json(['message' => 'Something went wrong. Please try again later.'], 500);
        }
    }

    // Haversine Distance Formula
    private function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371; // km
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat / 2) * sin($dLat / 2) +
            cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
            sin($dLon / 2) * sin($dLon / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return round($earthRadius * $c, 2);
    }

    /**
     * List all companies except logged-in user's company.
     */
    public function listCompanies()
    {
        try {
            // 1️⃣ Authenticate user
            if (!$user = JWTAuth::parseToken()->authenticate()) {
                Log::warning('Unauthorized access attempt in listCompanies()');
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized user'
                ], 401);
            }

            // 2️⃣ Get all companies except user's company (exclude admin-blocked)
            $companies = Company::with(['country', 'state', 'city'])
                ->where('id', '!=', $user->company_id)
                ->whereNull('blocked_by_admin_at')
                ->get();

            // 3️⃣ Fetch all ratings for these companies (single query)
            $companyIds = $companies->pluck('id');

            // Calculate average ratings and counts from job_ratings (new rating system)
            // Join job_ratings -> supply_jobs -> companies where provider_id = company.id
            $jobRatingsData = DB::table('job_ratings')
                ->join('supply_jobs', 'job_ratings.supply_job_id', '=', 'supply_jobs.id')
                ->whereIn('supply_jobs.provider_id', $companyIds)
                ->whereNotNull('job_ratings.rated_at')
                ->groupBy('supply_jobs.provider_id')
                ->select(
                    'supply_jobs.provider_id',
                    DB::raw('AVG(job_ratings.rating) as avg_rating'),
                    DB::raw('COUNT(job_ratings.id) as rating_count')
                )
                ->get()
                ->keyBy('provider_id');

            $jobRatingsAvg = $jobRatingsData->pluck('avg_rating', 'provider_id')->toArray();
            $jobRatingsCount = $jobRatingsData->pluck('rating_count', 'provider_id')->toArray();

            // Star breakdown from job_ratings (new system): count per provider_id and rating 1–5
            $jobBreakdownRows = DB::table('job_ratings')
                ->join('supply_jobs', 'job_ratings.supply_job_id', '=', 'supply_jobs.id')
                ->whereIn('supply_jobs.provider_id', $companyIds)
                ->whereNotNull('job_ratings.rated_at')
                ->whereBetween('job_ratings.rating', [1, 5])
                ->groupBy('supply_jobs.provider_id', 'job_ratings.rating')
                ->select('supply_jobs.provider_id', 'job_ratings.rating', DB::raw('COUNT(job_ratings.id) as cnt'))
                ->get();

            $jobRatingsBreakdown = [];
            foreach ($jobBreakdownRows as $row) {
                $id = $row->provider_id;
                if (!isset($jobRatingsBreakdown[$id])) {
                    $jobRatingsBreakdown[$id] = ['1' => 0, '2' => 0, '3' => 0, '4' => 0, '5' => 0];
                }
                $jobRatingsBreakdown[$id][(string) $row->rating] = (int) $row->cnt;
            }

            // Calculate average ratings and counts from company_ratings (old manual rating system) as fallback
            $companyRatingsData = DB::table('company_ratings')
                ->whereIn('company_id', $companyIds)
                ->groupBy('company_id')
                ->select(
                    'company_id',
                    DB::raw('AVG(rating) as avg_rating'),
                    DB::raw('COUNT(id) as rating_count')
                )
                ->get()
                ->keyBy('company_id');

            $companyRatingsAvg = $companyRatingsData->pluck('avg_rating', 'company_id')->toArray();
            $companyRatingsCount = $companyRatingsData->pluck('rating_count', 'company_id')->toArray();

            // Star breakdown from company_ratings (old system)
            $companyBreakdownRows = DB::table('company_ratings')
                ->whereIn('company_id', $companyIds)
                ->whereBetween('rating', [1, 5])
                ->groupBy('company_id', 'rating')
                ->select('company_id', 'rating', DB::raw('COUNT(id) as cnt'))
                ->get();

            $companyRatingsBreakdown = [];
            foreach ($companyBreakdownRows as $row) {
                $id = $row->company_id;
                if (!isset($companyRatingsBreakdown[$id])) {
                    $companyRatingsBreakdown[$id] = ['1' => 0, '2' => 0, '3' => 0, '4' => 0, '5' => 0];
                }
                $companyRatingsBreakdown[$id][(string) $row->rating] = (int) $row->cnt;
            }

            $userRatings = CompanyRating::whereIn('company_id', $companyIds)
                ->where('user_id', $user->id)
                ->pluck('rating', 'company_id'); // key = company_id, value = rating

            // 4️⃣ Fetch all blocked companies (single query)
            $blockedCompanies = CompanyBlock::whereIn('company_id', $companyIds)
                ->where('user_id', $user->id)
                ->pluck('company_id')
                ->toArray();

            // 5️⃣ Final response map (no queries inside)
            $formatted = $companies->map(function ($company) use (
                $jobRatingsAvg,
                $jobRatingsCount,
                $jobRatingsBreakdown,
                $companyRatingsAvg,
                $companyRatingsCount,
                $companyRatingsBreakdown,
                $userRatings,
                $blockedCompanies
            ) {
                // Calculate average rating and count: prioritize job_ratings (new system) if available
                $avgRating = 0;
                $ratingCount = 0;
                $ratingBreakdown = null;

                if (isset($jobRatingsAvg[$company->id])) {
                    $avgRating = $jobRatingsAvg[$company->id];
                    $ratingCount = (int) ($jobRatingsCount[$company->id] ?? 0);
                    $ratingBreakdown = $ratingCount > 0
                        ? ($jobRatingsBreakdown[$company->id] ?? ['1' => 0, '2' => 0, '3' => 0, '4' => 0, '5' => 0])
                        : null;
                } elseif (isset($companyRatingsAvg[$company->id])) {
                    $avgRating = $companyRatingsAvg[$company->id];
                    $ratingCount = (int) ($companyRatingsCount[$company->id] ?? 0);
                    $ratingBreakdown = $ratingCount > 0
                        ? ($companyRatingsBreakdown[$company->id] ?? ['1' => 0, '2' => 0, '3' => 0, '4' => 0, '5' => 0])
                        : null;
                }

                $displayAverageRating = $company->rating_override !== null
                    ? (float) $company->rating_override
                    : (float) $avgRating;

                return [
                    'id' => $company->id,
                    'name' => $company->name,
                    'company_logo' => DefaultImagePath::companyLogo($company->logo),

                    // Location fields
                    'city' => $company->city?->name ?? null,
                    'state' => $company->state?->name ?? null,
                    'country' => $company->country?->name ?? null,

                    // Ratings: average, count, and star breakdown for popup (progress bars)
                    // If admin override exists, use it for the displayed overall rating (keep count/breakdown from user ratings).
                    'average_rating' => round($displayAverageRating, 1),
                    'rating_count' => (int) $ratingCount,
                    'rating_breakdown' => $ratingBreakdown,

                    'user_rating' => $userRatings[$company->id] ?? null,

                    // Block status
                    'is_blocked' => in_array($company->id, $blockedCompanies),
                ];
            });

            return response()->json([
                'success' => true,
                'companies' => $formatted
            ], 200);

        } catch (\Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {
            Log::error('Invalid token in listCompanies()', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Invalid authentication token'
            ], 401);

        } catch (\Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
            Log::error('Expired token in listCompanies()', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Token has expired'
            ], 401);

        } catch (\Exception $e) {
            Log::error('Error fetching companies list', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to fetch companies. Please try again later.'
            ], 500);
        }
    }

    /**
     * Add or update rating for a company.
     */
    public function rateCompany(Request $request, $companyId)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();

            if ($user->company_id == $companyId) {
                return response()->json([
                    'success' => false,
                    'message' => 'You cannot rate your own company'
                ], 403);
            }

            $validator = Validator::make($request->all(), [
                'rating' => 'required|integer|min:1|max:5'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'errors' => $validator->errors()
                ], 422);
            }

            CompanyRating::updateOrCreate(
                ['company_id' => $companyId, 'user_id' => $user->id],
                ['rating' => $request->rating]
            );

            // Update consolidated rating in companies table
            $avgRating = CompanyRating::where('company_id', $companyId)->avg('rating');
            Company::where('id', $companyId)->update(['rating' => $avgRating]);

            return response()->json([
                'success' => true,
                'message' => 'Rating updated successfully',
                'average_rating' => round($avgRating, 1)
            ]);

        } catch (\Exception $e) {
            Log::error('Error rating company', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to update rating'
            ], 500);
        }
    }

    /**
     * Get customer reviews for a company.
     * Returns individual ratings with comments from job_ratings (new system) and company_ratings (old system).
     */
    public function getCompanyReviews($companyId)
    {
        try {
            // Authenticate user
            if (!$user = JWTAuth::parseToken()->authenticate()) {
                Log::warning('Unauthorized access attempt in getCompanyReviews()');
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized user'
                ], 401);
            }

            // Verify company exists
            $company = Company::find($companyId);
            if (!$company) {
                return response()->json([
                    'success' => false,
                    'message' => 'Company not found'
                ], 404);
            }

            $reviews = [];

            // 1️⃣ Get reviews from job_ratings (new system) - ratings from completed jobs
            $jobRatings = DB::table('job_ratings')
                ->join('supply_jobs', 'job_ratings.supply_job_id', '=', 'supply_jobs.id')
                ->join('rental_jobs', 'job_ratings.rental_job_id', '=', 'rental_jobs.id')
                ->join('users', 'rental_jobs.user_id', '=', 'users.id')
                ->leftJoin('companies', 'users.company_id', '=', 'companies.id')
                ->where('supply_jobs.provider_id', $companyId)
                ->whereNotNull('job_ratings.rated_at')
                ->whereNotNull('job_ratings.rating')
                ->select(
                    'job_ratings.id',
                    'job_ratings.rating',
                    'job_ratings.comment',
                    'job_ratings.rated_at',
                    'rental_jobs.name as job_name',
                    'users.name as renter_name',
                    'companies.name as renter_company_name',
                    DB::raw("'job' as source")
                )
                ->orderBy('job_ratings.rated_at', 'desc')
                ->get();

            foreach ($jobRatings as $rating) {
                $reviews[] = [
                    'id' => $rating->id,
                    'rating' => (int) $rating->rating,
                    'comment' => $rating->comment,
                    'rated_at' => $rating->rated_at ? date('c', strtotime($rating->rated_at)) : null,
                    'renter_name' => $rating->renter_name,
                    'renter_company_name' => $rating->renter_company_name,
                    'job_name' => $rating->job_name,
                    'source' => 'job',
                ];
            }

            // 2️⃣ Get reviews from company_ratings (old manual rating system) as fallback
            $companyRatings = DB::table('company_ratings')
                ->join('users', 'company_ratings.user_id', '=', 'users.id')
                ->leftJoin('companies', 'users.company_id', '=', 'companies.id')
                ->where('company_ratings.company_id', $companyId)
                ->select(
                    'company_ratings.id',
                    'company_ratings.rating',
                    DB::raw('NULL as comment'),
                    'company_ratings.created_at as rated_at',
                    DB::raw('NULL as job_name'),
                    'users.name as renter_name',
                    'companies.name as renter_company_name',
                    DB::raw("'manual' as source")
                )
                ->orderBy('company_ratings.created_at', 'desc')
                ->get();

            foreach ($companyRatings as $rating) {
                // Only add if not already covered by job_ratings (avoid duplicates)
                // Since company_ratings is old system, we'll include them but mark as manual
                $reviews[] = [
                    'id' => $rating->id,
                    'rating' => (int) $rating->rating,
                    'comment' => null,
                    'rated_at' => $rating->rated_at ? date('c', strtotime($rating->rated_at)) : null,
                    'renter_name' => $rating->renter_name,
                    'renter_company_name' => $rating->renter_company_name,
                    'job_name' => null,
                    'source' => 'manual',
                ];
            }

            // 3️⃣ Aggregate rating stats (same rules as other endpoints)
            $avgRating = 0.0;
            $ratingCount = 0;
            $ratingBreakdown = ['1' => 0, '2' => 0, '3' => 0, '4' => 0, '5' => 0];

            // Job ratings first
            $jobStats = DB::table('job_ratings')
                ->join('supply_jobs', 'job_ratings.supply_job_id', '=', 'supply_jobs.id')
                ->where('supply_jobs.provider_id', $companyId)
                ->whereNotNull('job_ratings.rated_at')
                ->whereNotNull('job_ratings.rating')
                ->select(
                    DB::raw('AVG(job_ratings.rating) as avg_rating'),
                    DB::raw('COUNT(job_ratings.id) as rating_count')
                )
                ->first();

            if ($jobStats && $jobStats->rating_count > 0) {
                $avgRating = (float) $jobStats->avg_rating;
                $ratingCount = (int) $jobStats->rating_count;

                $jobBreakdownRows = DB::table('job_ratings')
                    ->join('supply_jobs', 'job_ratings.supply_job_id', '=', 'supply_jobs.id')
                    ->where('supply_jobs.provider_id', $companyId)
                    ->whereNotNull('job_ratings.rated_at')
                    ->whereNotNull('job_ratings.rating')
                    ->select('job_ratings.rating', DB::raw('COUNT(*) as cnt'))
                    ->groupBy('job_ratings.rating')
                    ->get();

                foreach ($jobBreakdownRows as $row) {
                    $key = (string) $row->rating;
                    if (array_key_exists($key, $ratingBreakdown)) {
                        $ratingBreakdown[$key] = (int) $row->cnt;
                    }
                }
            } else {
                // Fallback to company_ratings
                $companyStats = DB::table('company_ratings')
                    ->where('company_id', $companyId)
                    ->select(
                        DB::raw('AVG(rating) as avg_rating'),
                        DB::raw('COUNT(id) as rating_count')
                    )
                    ->first();

                if ($companyStats && $companyStats->rating_count > 0) {
                    $avgRating = (float) $companyStats->avg_rating;
                    $ratingCount = (int) $companyStats->rating_count;

                    $companyBreakdownRows = DB::table('company_ratings')
                        ->where('company_id', $companyId)
                        ->select('rating', DB::raw('COUNT(*) as cnt'))
                        ->groupBy('rating')
                        ->get();

                    foreach ($companyBreakdownRows as $row) {
                        $key = (string) $row->rating;
                        if (array_key_exists($key, $ratingBreakdown)) {
                            $ratingBreakdown[$key] = (int) $row->cnt;
                        }
                    }
                }
            }

            // Apply admin override for displayed average, if present (keeps breakdown from user ratings)
            $displayAverageRating = $company->rating_override !== null
                ? (float) $company->rating_override
                : $avgRating;

            // Sort all reviews by rated_at descending (most recent first)
            usort($reviews, function ($a, $b) {
                $timeA = $a['rated_at'] ? strtotime($a['rated_at']) : 0;
                $timeB = $b['rated_at'] ? strtotime($b['rated_at']) : 0;
                return $timeB - $timeA;
            });

            return response()->json([
                'success' => true,
                'data' => [
                    'company_id' => (int) $companyId,
                    'company_name' => $company->name,
                    'reviews' => $reviews,
                    'total_reviews' => count($reviews),
                    'average_rating' => round($displayAverageRating, 1),
                    'user_average_rating' => round($avgRating, 1),
                    'rating_count' => (int) $ratingCount,
                    'rating_breakdown' => $ratingCount > 0 ? $ratingBreakdown : null,
                ]
            ], 200);

        } catch (\Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {
            Log::error('Invalid token in getCompanyReviews()', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Invalid authentication token'
            ], 401);

        } catch (\Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
            Log::error('Expired token in getCompanyReviews()', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Token has expired'
            ], 401);

        } catch (\Exception $e) {
            Log::error('Error fetching company reviews', ['error' => $e->getMessage(), 'company_id' => $companyId]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to fetch reviews. Please try again later.'
            ], 500);
        }
    }

    /**
     * Block a company for the logged-in user.
     */
    public function blockCompany(Request $request, $companyId)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();

            if ($user->company_id == $companyId) {
                return response()->json([
                    'success' => false,
                    'message' => 'You cannot block your own company'
                ], 403);
            }

            $block = $request->input('block', true); // default true if not passed

            if ($block) {
                // Block company
                CompanyBlock::firstOrCreate([
                    'company_id' => $companyId,
                    'user_id' => $user->id,
                ]);

                return response()->json([
                    'success' => true,
                    'message' => 'Company blocked successfully',
                    'data' => [
                        'company_id' => $companyId,
                        'is_blocked' => true
                    ]
                ], 200);

            } else {
                // Unblock company
                CompanyBlock::where('company_id', $companyId)
                    ->where('user_id', $user->id)
                    ->delete();

                return response()->json([
                    'success' => true,
                    'message' => 'Company unblocked successfully',
                    'data' => [
                        'company_id' => $companyId,
                        'is_blocked' => false
                    ]
                ], 200);
            }

        } catch (\Exception $e) {
            Log::error('Error blocking/unblocking company', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to update block status'
            ], 500);
        }
    }

    /**
     * Unblock a company for the logged-in user.
     */
    public function unblockCompany($companyId)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();

            CompanyBlock::where('company_id', $companyId)
                ->where('user_id', $user->id)
                ->delete();

            return response()->json([
                'success' => true,
                'message' => 'Company unblocked successfully'
            ]);

        } catch (\Exception $e) {
            Log::error('Error unblocking company', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Unable to unblock company'
            ], 500);
        }
    }

    /**
     * Block or unblock a provider company for the logged-in user's company.
     */
    public function toggleProviderBlock(Request $request, $providerId)
    {
        try {
            $user = JWTAuth::parseToken()->authenticate();
            $companyId = $user->company_id;

            // Safety: prevent blocking own company
            if ($companyId == $providerId) {
                return response()->json([
                    'success' => false,
                    'message' => 'You cannot block your own company'
                ], 403);
            }

            $block = $request->boolean('block', true);

            if ($block) {
                // Block provider for company
                CompanyProviderBlock::updateOrCreate(
                    [
                        'company_id' => $companyId,
                        'provider_id' => $providerId,
                    ],
                    [
                        'blocked_by_user_id' => $user->id,
                        'blocked_at' => now(),
                    ]
                );

                return response()->json([
                    'success' => true,
                    'message' => 'Provider blocked successfully',
                    'data' => [
                        'provider_id' => $providerId,
                        'is_blocked' => true
                    ]
                ], 200);
            }

            // Unblock provider
            CompanyProviderBlock::where('company_id', $companyId)
                ->where('provider_id', $providerId)
                ->delete();

            return response()->json([
                'success' => true,
                'message' => 'Provider unblocked successfully',
                'data' => [
                    'provider_id' => $providerId,
                    'is_blocked' => false
                ]
            ], 200);

        } catch (\Throwable $e) {
            Log::error('Provider block toggle failed', [
                'error' => $e->getMessage(),
                'user_id' => $user->id ?? null,
                'provider_id' => $providerId
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Unable to update provider block status'
            ], 500);
        }
    }


}
