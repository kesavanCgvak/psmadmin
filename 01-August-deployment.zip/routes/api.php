<?php

use App\Http\Controllers\Api\AuthController;
// Duplicate import removed during formatting cleanup
use App\Http\Controllers\Api\BrandController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\CityController;
use App\Http\Controllers\Api\CmsPageController as ApiCmsPageController;
use App\Http\Controllers\Api\CommentController;
use App\Http\Controllers\Api\CompanyController;
use App\Http\Controllers\Api\CompanyUserController;
use App\Http\Controllers\Api\CompanyUserLimitController;
use App\Http\Controllers\Api\CurrencyController;
use App\Http\Controllers\Api\DateFormatController;
use App\Http\Controllers\Api\EquipmentController;
use App\Http\Controllers\Api\FlexInventoryController;
use App\Http\Controllers\Api\RentmanEquipmentController;
use App\Http\Controllers\Api\ForgotPasswordController;
use App\Http\Controllers\Api\GeoController;
use App\Http\Controllers\Api\ImportController;
use App\Http\Controllers\Api\IntegrationController;
use App\Http\Controllers\Api\InventoryMasterDataController;
use App\Http\Controllers\Api\InventoryMasterSpecExportController;
use App\Http\Controllers\Api\IssueTypeController;
use App\Http\Controllers\Api\JobNegotiationController;
use App\Http\Controllers\Api\LocationController;
use App\Http\Controllers\Api\MailTestController;
use App\Http\Controllers\Api\MeasurementUnitController;
use App\Http\Controllers\Api\PaymentStatusController;
use App\Http\Controllers\Api\PartnerProductController;
use App\Http\Controllers\Api\PricingSchemeController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\PromotionalLogoController;
use App\Http\Controllers\Api\ProviderApiKeyController;
use App\Http\Controllers\Api\RegistrationCheckController;
use App\Http\Controllers\Api\RentalJobActionsController;
use App\Http\Controllers\Api\RentalJobController;
use App\Http\Controllers\Api\RentalRequestController;
use App\Http\Controllers\Api\RentalSoftwareController;
use App\Http\Controllers\Api\RentalSoftwareCompanyLogoController;
use App\Http\Controllers\Api\StateController;
use App\Http\Controllers\Api\StripeWebhookController;
use App\Http\Controllers\Api\SubCategoryController;
use App\Http\Controllers\Api\SubscriptionController;
use App\Http\Controllers\Api\SupplyJobActionsController;
use App\Http\Controllers\Api\SupplyJobController;
use App\Http\Controllers\Api\SupportRequestController;
use App\Http\Controllers\Api\TermsAndConditionsController;
use App\Http\Controllers\Api\UserProfileController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('register', [AuthController::class, 'register']);
Route::post('login', [AuthController::class, 'login']);
Route::get('/products/search', [ProductController::class, 'search']);
Route::post('/auth/verify-account', [AuthController::class, 'verifyAccount']);
Route::post('/password/forgot', [ForgotPasswordController::class, 'sendResetLink']);
Route::post('/reset-password/{token}', [ForgotPasswordController::class, 'reset']);
Route::post('/auth/refresh', [AuthController::class, 'refresh']);

// Registration availability checks (public, JSON body)
Route::post('/registration/availability', [RegistrationCheckController::class, 'checkAvailability']);
Route::post('/contact-sales', [SupportRequestController::class, 'contactSales']);

// Mail Test API (public, for testing and debugging mail configuration only)
Route::post('/mail/test', [MailTestController::class, 'testEmail']);

// Payment status check (public endpoint for frontend)
Route::get('/payment/status', [PaymentStatusController::class, 'status']);

// Company user limit (public endpoint for frontend)
Route::get('/company-user-limit', [CompanyUserLimitController::class, 'getLimit']);

// Terms and Conditions (public endpoint)
Route::get('/terms-and-conditions', [TermsAndConditionsController::class, 'index']);

// Rental software company logos (public endpoint)
Route::get('/rental-software-company-logos', [RentalSoftwareCompanyLogoController::class, 'index']);

// Promotional company logos (public endpoint; user consent + admin approval)
Route::get('/promotional-logos', [PromotionalLogoController::class, 'index']);


// CMS pages (public; HTML already sanitized when saved in admin)
Route::get('/cms-pages', [ApiCmsPageController::class, 'index']);
Route::get('/cms-pages/{slug}', [ApiCmsPageController::class, 'show']);

// ------------------------------
// 🌐 Geography APIs
// ------------------------------
// These should be public (no auth middleware)
Route::get('/regions', [GeoController::class, 'getRegions']);
Route::get('/countries', [GeoController::class, 'getCountries']);
Route::get('/regions/{region_id}/countries', [GeoController::class, 'getCountriesByRegion']);
Route::get('/countries/{country_id}/cities', [GeoController::class, 'getCitiesByCountry']);

Route::get('countries/{country}/states', [StateController::class, 'index']);
Route::get('states/{state}', [StateController::class, 'show']);
Route::get('states/{state}/cities', [CityController::class, 'indexByState']);
// Route::get('countries/{country}/cities', [CityController::class, 'indexByCountry']);
// Route::get('locations/hierarchy', [LocationController::class, 'hierarchy']);

// ------------------------------
// 📦 Brands, Categories & Subcategories (Auth Required)
// ------------------------------
Route::middleware('jwt.verify')->group(function () {
    Route::get('/brands', [BrandController::class, 'index']);
    Route::get('/categories', [CategoryController::class, 'index']);
    Route::get('/sub-categories', [SubCategoryController::class, 'index']);
    Route::get('/categories/{id}/sub-categories', [SubCategoryController::class, 'getByCategory'])
        ->whereNumber('id');

    // Issue Types
    Route::get('/issue-types', [IssueTypeController::class, 'index']);
});

// ------------------------------
// 👤 Profile APIs
// ------------------------------
Route::middleware('jwt.verify')->group(function () {
    Route::get('/user/profile', [UserProfileController::class, 'getProfile']);
    Route::post('/profile/upload-picture', [UserProfileController::class, 'uploadPicture']);
    Route::post('/profile/change-password', [UserProfileController::class, 'changePassword']);

    // Individual profile field updates
    Route::patch('/profile/update-username', [UserProfileController::class, 'updateUsername']);
    Route::patch('/profile/update-name', [UserProfileController::class, 'updateName']);
    Route::patch('/profile/update-email', [UserProfileController::class, 'updateEmail']);
    Route::patch('/profile/update-mobile', [UserProfileController::class, 'updateMobile']);
    Route::get('/rental-softwares', [RentalSoftwareController::class, 'index']);
    Route::get('/currencies', [CurrencyController::class, 'index']);
    Route::get('/date-formats', [DateFormatController::class, 'index']);
    Route::get('/linear-units', [MeasurementUnitController::class, 'linearUnits']);
    Route::get('/weight-units', [MeasurementUnitController::class, 'weightUnits']);
    Route::get('/pricing-schemes', [PricingSchemeController::class, 'index']);
});

// ------------------------------
// 🏢 Company Management
// ------------------------------
Route::middleware('jwt.verify')->group(function () {
    Route::post('/company/users', [CompanyUserController::class, 'store']);
    Route::get('/company/users', [CompanyUserController::class, 'getCompanyUsers']);
    Route::put('/company/users/{id}', [CompanyUserController::class, 'updateCompanyUser']);
    Route::delete('/company/users/{id}', [CompanyUserController::class, 'deleteUser']);
    Route::put('/company/users/{id}/make-admin', [CompanyUserController::class, 'makeAdmin']);

    Route::get('/company/info', [CompanyController::class, 'getInfo']);
    Route::put('/company/info/update', [CompanyController::class, 'updateCompanyInfo']);
    Route::get('/company/default-contact', [CompanyController::class, 'getDefaultContact']);
    Route::put('/company/default-contact', [CompanyController::class, 'updateDefaultContact']);

    // Route::put('/company/info', [CompanyController::class, 'updateInfo']);
    Route::get('/company/preferences', [CompanyController::class, 'getPreferences']);
    Route::put('/company/preferences', [CompanyController::class, 'updatePreferences']);
    Route::put('/companies/{id}/gear-finder-visibility', [CompanyController::class, 'updateGearFinderVisibility']);
    Route::put('/company/logo-promotion-consent', [CompanyController::class, 'updateLogoPromotionConsent']);

    Route::get('/company/images', [CompanyController::class, 'getImages']);
    Route::post('/company/images', [CompanyController::class, 'uploadImage']);
    Route::delete('/company/images', [CompanyController::class, 'deleteImage']);

    Route::get('/company/address', [CompanyController::class, 'getAddress']);
    Route::patch('/company/address', [CompanyController::class, 'updateAddress']);

    Route::get('/company/search-priority', [CompanyController::class, 'getSearchPriority']);
    Route::patch('/company/search-priority', [CompanyController::class, 'updateSearchPriority']);
});

Route::middleware('jwt.verify')->group(function () {
    Route::post('/companies/search', [CompanyController::class, 'searchCompanies']);
    Route::post('/company/search-priority', [CompanyController::class, 'searchPriority']);
    // Company listing
    Route::get('/companies', [CompanyController::class, 'listCompanies']);

    // Add/Update rating
    Route::post('/companies/{company}/rate', [CompanyController::class, 'rateCompany']);

    // Get company reviews (customer reviews)
    Route::get('/companies/{company}/reviews', [CompanyController::class, 'getCompanyReviews']);

    // Block/Unblock company
    Route::post('/companies/{company}/block', [CompanyController::class, 'blockCompany']);
    Route::post('/companies/{company}/unblock', [CompanyController::class, 'unblockCompany']);
    Route::post('/providers/{company}/block', [CompanyController::class, 'toggleProviderBlock']);

});

Route::middleware('jwt.verify')->get('/products/{product_id}', [ProductController::class, 'show'])
    ->whereNumber('product_id');
Route::middleware('jwt.verify')->get('/inventory-master/physical-details', [InventoryMasterDataController::class, 'show']);
Route::middleware(['jwt.verify', 'throttle:5,1'])->post(
    '/inventory-master/specifications/export-sql',
    [InventoryMasterSpecExportController::class, 'export']
);
Route::middleware('jwt.verify')->post('/products/create-or-attach', [ProductController::class, 'createOrAttach']);
Route::middleware('jwt.verify')->post('/products/import', [ProductController::class, 'importProducts']); // Legacy endpoint

// New Import Workflow with Preview and Persistent Draft State
Route::middleware('jwt.verify')->prefix('import')->group(function () {
    Route::get('/sessions', [ImportController::class, 'index']); // List active sessions
    Route::post('/sessions', [ImportController::class, 'start']); // Start new session
    Route::get('/sessions/{session}', [ImportController::class, 'show']); // Get session with items
    Route::post('/sessions/{session}/upload', [ImportController::class, 'upload']); // Upload Excel
    Route::post('/sessions/{session}/analyze', [ImportController::class, 'analyze']); // Run matching
    Route::post('/sessions/{session}/reanalyze', [ImportController::class, 'reanalyze']); // Force re-analysis using stored data
    Route::put('/sessions/{session}/selections', [ImportController::class, 'updateSelections']); // Save draft selections
    Route::delete('/sessions/{session}/items/{item}', [ImportController::class, 'removeItem']); // Remove row from import
    Route::post('/sessions/{session}/confirm', [ImportController::class, 'confirm']); // Confirm and import
    Route::post('/sessions/{session}/cancel', [ImportController::class, 'cancel']); // Cancel session
});

Route::middleware(['jwt.verify'])->group(function () {
    Route::post('/integrations/store', [IntegrationController::class, 'store']);
    Route::get('/integrations/{integration_type}', [IntegrationController::class, 'show']);
    Route::post('/integrations/sync-status', [IntegrationController::class, 'syncStatus']);
});

Route::middleware(['jwt.verify', 'throttle:12,1'])->prefix('provider/api-keys')->group(function () {
    Route::get('/', [ProviderApiKeyController::class, 'index']);
    Route::post('/generate', [ProviderApiKeyController::class, 'generate']);
    Route::post('/request-access', [ProviderApiKeyController::class, 'requestAccess']);
    Route::get('/{id}/reveal', [ProviderApiKeyController::class, 'reveal'])->whereNumber('id');
    Route::post('/{id}/revoke', [ProviderApiKeyController::class, 'revoke'])->whereNumber('id');
});

Route::prefix('v1/partner')->middleware(['provider.api.key', 'throttle:60,1'])->group(function () {
    Route::get('/products/search', [PartnerProductController::class, 'search']);
    Route::get('/products/{product_id}', [PartnerProductController::class, 'details'])->whereNumber('product_id');
});

// Flex Rental Solutions inventory import (company-specific credentials)
Route::middleware(['jwt.verify'])->prefix('flex')->group(function () {
    Route::get('/search', [FlexInventoryController::class, 'search']);
    Route::get('/import/check', [FlexInventoryController::class, 'checkImport']);
    Route::post('/import', [FlexInventoryController::class, 'import']);
    Route::post('/link-inventory', [FlexInventoryController::class, 'linkInventory']);
});

Route::middleware(['jwt.verify'])->prefix('company-inventory')->group(function () {
    Route::post('/search-flex-product', [FlexInventoryController::class, 'searchFlexProduct']);
    Route::post('/confirm-flex-sync', [FlexInventoryController::class, 'confirmFlexSync']);
});

// Rentman equipment (local cache + import; search is DB-only)
Route::middleware(['jwt.verify'])->prefix('rentman/equipment')->group(function () {
    Route::post('/sync', [RentmanEquipmentController::class, 'sync']);
    Route::get('/search', [RentmanEquipmentController::class, 'search']);
    Route::get('/import/check', [RentmanEquipmentController::class, 'checkImport']);
    Route::post('/import', [RentmanEquipmentController::class, 'import']);
    Route::post('/link-inventory', [RentmanEquipmentController::class, 'linkInventory']);
});

Route::middleware(['jwt.verify'])->group(function () {
    // Equipment CRUD
    Route::post('/equipments', [EquipmentController::class, 'store']);
    Route::get('/equipments', [EquipmentController::class, 'getCompanyEquipments']);
    Route::get('/company-equipments/{id}', [EquipmentController::class, 'showCompanyEquipment'])
        ->whereNumber('id');
    Route::delete('/equipments/{equipment}', [EquipmentController::class, 'destroy']);

    // Updates
    Route::put('/equipments/{equipment}/quantity', [EquipmentController::class, 'updateQuantity']);
    Route::put('/equipments/{equipment}/price', [EquipmentController::class, 'updatePrice']);
    Route::put('/equipments/{equipment}/software-code', [EquipmentController::class, 'updateSoftwareCode']);
    Route::put('/equipments/{equipment}/description', [EquipmentController::class, 'updateDescription']);
    Route::put('/equipments/{equipment}/marketplace-details', [EquipmentController::class, 'updateMarketplaceDetails']);

    // Images
    Route::post('/equipments/{equipment}/images', [EquipmentController::class, 'addImages']);
    Route::delete('/equipments/images/{id}', [EquipmentController::class, 'deleteImage']);
});

Route::get('/rental-shipping-methods', [RentalRequestController::class, 'shippingMethods']);

Route::middleware(['jwt.verify'])->group(function () {
    Route::post('/rental-requests', [RentalRequestController::class, 'store']);
});

Route::middleware(['jwt.verify'])->group(function () {
    Route::get('profile', [AuthController::class, 'profile']);
    Route::post('logout', [AuthController::class, 'logout']);
});

Route::middleware(['jwt.verify'])->group(function () {
    Route::get('/rental-jobs', [RentalJobController::class, 'index']); // List jobs
    Route::get('/rental-jobs/{id}', [RentalJobController::class, 'show']); // Job detail
    Route::get('/rental-jobs/{rentalJobId}/suppliers/{supplyJobId}', [RentalJobController::class, 'supplierDetails']); // Supplier detail
});

Route::middleware(['jwt.verify'])->group(function () {
    // Update rental job basics
    Route::put('/rental-jobs/{id}/basics', [RentalJobActionsController::class, 'updateBasics']);

    // Update requested product quantities
    Route::put('/rental-jobs/{id}/quantities', [RentalJobActionsController::class, 'updateRequestedQuantities']);

    Route::post('/rental-jobs/{id}/cancel', [RentalJobActionsController::class, 'cancelRentalJob']);

    Route::post('/rental-jobs/{id}/rate', [RentalJobActionsController::class, 'rate']);
    Route::post('/rental-jobs/{id}/rate/skip', [RentalJobActionsController::class, 'rateSkip']);

});

Route::group(['middleware' => ['jwt.verify']], function () {

    // uopdate supply job name
    Route::put('/supply-jobs/{id}/name', [SupplyJobActionsController::class, 'updateName']);

    // Update milestone dates
    Route::put('/supply-jobs/{id}/milestones', [SupplyJobActionsController::class, 'updateMilestoneDates']);

    // Update supply quantities
    Route::put('/supply-jobs/{id}/quantities', [SupplyJobActionsController::class, 'updateSupplyQuantities']);

    // Send offer
    Route::post('/supply-jobs/{id}/offer', [SupplyJobActionsController::class, 'sendNewOffer']);

    // Handshake (accept offer)
    // Route::post('/supply-jobs/{id}/handshake', [SupplyJobActionsController::class, 'handshake']);

    // Cancel negotiation
    // Route::post('/supply-jobs/{id}/cancel', [SupplyJobActionsController::class, 'cancelNegotiation']);

});

Route::middleware(['jwt.verify'])->group(function () {
    Route::get('/supply-jobs', [SupplyJobController::class, 'index']); // ?company_id=123
    Route::get('/supply-jobs/{id}', [SupplyJobController::class, 'show']); // ?company_id=123
    Route::post('/supply-jobs/{supply_job_id}/cancel', [SupplyJobController::class, 'cancelSupplyJob']);
    Route::post('/supply-jobs/{id}/complete', [SupplyJobController::class, 'complete']);
    Route::post('/supply-jobs/{id}/rate', [SupplyJobController::class, 'rate']);
    Route::post('/supply-jobs/{id}/rate/skip', [SupplyJobController::class, 'rateSkip']);
    Route::post('/supply-jobs/{id}/rate-renter', [SupplyJobController::class, 'rateRenter']);
    Route::post('/supply-jobs/{id}/rate-renter/skip', [SupplyJobController::class, 'rateRenterSkip']);
    Route::post('/supply-jobs/{id}/rating-reply', [SupplyJobController::class, 'ratingReply']);
});

Route::prefix('jobs')->middleware(['jwt.verify'])->group(function () {
    Route::post('{rental_job}/offer', [JobNegotiationController::class, 'sendOffer']);
});

Route::prefix('offers')->middleware(['jwt.verify'])->group(function () {
    Route::post('{offer_id}/handshake', [JobNegotiationController::class, 'handshake']);
    Route::post('{offer_id}/cancel-negotiation', [JobNegotiationController::class, 'cancelNegotiation']);
});

Route::middleware('jwt.verify')->group(function () {
    // Comments on supply jobs
    Route::get('/supply-jobs/{supplyJobId}/comments', [CommentController::class, 'index']);
    Route::post('/supply-jobs/{supplyJobId}/comments', [CommentController::class, 'store']);

    // Comment management
    Route::put('/comments/{commentId}', [CommentController::class, 'update']);
    Route::delete('/comments/{commentId}', [CommentController::class, 'destroy']);

    // Support Request API
    Route::post('/support-request', [SupportRequestController::class, 'store']);
});

// ------------------------------
// 💳 Stripe Webhook (No auth required)
// ------------------------------
Route::post('/webhooks/stripe', [StripeWebhookController::class, 'handleWebhook']);

// ------------------------------
// 📅 Subscription Management
// ------------------------------
Route::middleware('jwt.verify')->group(function () {
    Route::get('/subscriptions/current', [SubscriptionController::class, 'getCurrent']);
    Route::get('/subscriptions/trial-incentive', [SubscriptionController::class, 'trialIncentive']);
    Route::post('/subscriptions/cancel', [SubscriptionController::class, 'cancel']);
    Route::post('/subscriptions/update-payment', [SubscriptionController::class, 'updatePaymentMethod']);
    Route::get('/subscription/payment-method', [SubscriptionController::class, 'getPaymentMethod']);
    Route::post('/subscriptions/create', [SubscriptionController::class, 'create']);

    // Billing History APIs
    Route::get('/subscription/billing-history', [SubscriptionController::class, 'billingHistory']);
    Route::get('/subscription/invoice/{invoiceId}', [SubscriptionController::class, 'downloadInvoice']);

});

// Contact Sales API (public, no authentication required)
