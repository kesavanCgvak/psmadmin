<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\RentalJob;
use App\Models\RentalJobProduct;
use App\Models\SupplyJob;
use App\Models\SupplyJobProduct;
use App\Models\RentalJobComment;
use App\Models\RentalJobOffer;
use App\Models\JobOffer;
use App\Models\JobRating;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Mail;
use App\Models\User;
use App\Models\UserProfile;
use App\Models\Company;
use App\Models\Product;
use App\Models\Equipment;
use App\Support\RentalShippingMethods;

class RentalJobController extends Controller
{

    /**
     * LIST: Rental jobs created by users in the same company (summary).
     * Supports filters. Secure & light-weight.
     * All users in the same company can see all rental jobs created by any user in that company.
     */
    public function index(Request $request)
    {
        $user = auth('api')->user(); // JWT guard

        // Validate query params
        $validated = $request->validate([
            'status' => ['nullable', Rule::in(['open', 'in_negotiation', 'accepted', 'cancelled', 'completed', 'partially_accepted', 'completed_pending_rating', 'rated', 'closed'])],
            'from_date' => ['nullable', 'date'],
            'to_date' => ['nullable', 'date', 'after_or_equal:from_date'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        try {
            // Filter by company_id: Get all rental jobs from users in the same company
            // Use whereHas to filter through the user relationship by company_id
            $query = RentalJob::query()
                ->whereHas('user', function ($q) use ($user) {
                    $q->where('company_id', $user->company_id);
                })
                ->with([
                    'products.product.brand',
                    'supplyJobs:id,rental_job_id,provider_id,status',
                    'supplyJobs.providerCompany:id,name',
                    'supplyJobs.cancelledByUser:id,is_admin',
                    'supplyJobs.jobRating',
                    'supplyJobs.ratingReply',
                    'supplyJobs.renterRating',
                ])
                ->orderBy('created_at', 'desc');

            // optional filters
            if (!empty($validated['status'])) {
                $query->where('status', $validated['status']);
            }
            if (!empty($validated['from_date'])) {
                $query->whereDate('from_date', '>=', $validated['from_date']);
            }
            if (!empty($validated['to_date'])) {
                $query->whereDate('to_date', '<=', $validated['to_date']);
            }

            //Pagination decision
            $perPage = $validated['per_page'] ?? null;

            if ($perPage) {
                $paginator = $query->paginate($perPage);
                $collection = $paginator->getCollection();
            } else {
                $collection = $query->get();
                $paginator = null;
            }

            //Transform data: include suppliers array so Rating column can show all company ratings
            $data = $collection->map(function (RentalJob $job) {
                $suppliers = $job->supplyJobs->map(function ($sj) {
                    $supplier = [
                        'supply_job_id' => $sj->id,
                        'company_id' => $sj->provider_id ?? $sj->providerCompany->id ?? null,
                        'company_name' => $sj->providerCompany->name ?? 'Unknown',
                        'status' => $this->effectiveSupplyJobStatus($sj),
                    ];
                    if ($sj->jobRating && $sj->jobRating->rated_at) {
                        $reply = $sj->ratingReply;
                        $supplier['supplier_rating'] = [
                            'rating' => (int) $sj->jobRating->rating,
                            'comment' => $sj->jobRating->comment,
                            'rated_at' => $sj->jobRating->rated_at->toIso8601String(),
                            'provider_reply' => $reply?->reply,
                            'provider_replied_at' => $reply?->replied_at?->toIso8601String(),
                        ];
                    }
                    if ($sj->jobRating && $sj->jobRating->skipped_at) {
                        $supplier['rating_skipped'] = true;
                    }
                    if ($sj->renterRating && $sj->renterRating->rated_at) {
                        $rr = $sj->renterRating;
                        $supplier['provider_rating_of_renter'] = [
                            'rating' => (int) $rr->rating,
                            'comment' => $rr->comment,
                            'rated_at' => $rr->rated_at->toIso8601String(),
                        ];
                    } else {
                        $supplier['provider_rating_of_renter'] = null;
                    }
                    return $supplier;
                })->values();

                $item = [
                    'id' => $job->id,
                    'name' => $job->name,
                    'from_date' => $job->from_date,
                    'to_date' => $job->to_date,
                    'delivery_address' => $job->delivery_address,
                    'shipping_method' => $job->shipping_method ?? RentalShippingMethods::default(),
                    'shipping_method_label' => RentalShippingMethods::label($job->shipping_method),
                    'status' => $job->status,
                    'products' => $job->products->map(function ($rp) {
                        $brand = $rp->product->brand->name ?? '';
                        $prod = $rp->product->name ?? $rp->product->model ?? '';

                        return [
                            'id' => $rp->product_id,
                            'name' => trim("{$brand} - {$prod}", ' -'),
                            'requested_quantity' => (int) $rp->requested_quantity,
                        ];
                    })->values(),
                    'provider_responses_count' => $job->supplyJobs->count(),
                    'suppliers' => $suppliers,
                ];

                // Fallback: single job_rating when one supplier (for backward compatibility)
                $ratedSupplier = $job->supplyJobs->first(fn ($sj) => $sj->jobRating && $sj->jobRating->rated_at);
                if ($ratedSupplier) {
                    $jr = $ratedSupplier->jobRating;
                    $reply = $ratedSupplier->ratingReply;
                    $item['job_rating'] = [
                        'rating' => (int) $jr->rating,
                        'comment' => $jr->comment,
                        'rated_at' => $jr->rated_at->toIso8601String(),
                        'provider_reply' => $reply?->reply,
                        'provider_replied_at' => $reply?->replied_at?->toIso8601String(),
                    ];
                }
                return $item;
            })->values();

            //Build response
            $response = [
                'success' => true,
                'data' => $data,
            ];

            //Pagination meta only when paginated
            if ($paginator) {
                $response['meta'] = [
                    'current_page' => $paginator->currentPage(),
                    'per_page' => $paginator->perPage(),
                    'total' => $paginator->total(),
                    'last_page' => $paginator->lastPage(),
                ];
            }

            return response()->json($response);

        } catch (\Throwable $e) {
            report($e);
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch rental jobs',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal Server Error',
            ], 500);
        }
    }


    /**
     * DETAIL: Basic rental job details only.
     * Returns basic info + list of suppliers (basic info only).
     * All users in the same company can view rental jobs created by any user in that company.
     */
    public function show(Request $request, $id)
    {
        $user = auth('api')->user();

        try {
            $job = RentalJob::with([
                'user:id,company_id',
                'supplyJobs:id,rental_job_id,provider_id,status',
                'supplyJobs.providerCompany:id,name',
                'supplyJobs.cancelledByUser:id,is_admin',
                'supplyJobs.jobRating',
                'supplyJobs.ratingReply',
                'supplyJobs.renterRating',
            ])->findOrFail($id);

            // Security: only users from the same company or admin can view
            $jobCreatorCompanyId = $job->user->company_id ?? null;
            if ($jobCreatorCompanyId !== $user->company_id && !$user->is_admin) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized to view this rental job.'
                ], 403);
            }

            // Build suppliers array: supplier_rating only from this supply job's rating (never copy to others).
            // Status "rated" is only shown when the renter has actually rated or skipped (job_rating has rated_at or skipped_at).
            $suppliers = $job->supplyJobs->map(function ($sj) {
                $supplier = [
                    'supply_job_id' => $sj->id,
                    'rental_job_id' => $sj->rental_job_id,
                    'company_id' => $sj->providerCompany->id ?? null,
                    'company_name' => $sj->providerCompany->name ?? 'Unknown',
                    'status' => $this->effectiveSupplyJobStatus($sj),
                ];
                if ($sj->jobRating && $sj->jobRating->rated_at) {
                    $reply = $sj->ratingReply;
                    $supplier['supplier_rating'] = [
                        'rating' => (int) $sj->jobRating->rating,
                        'comment' => $sj->jobRating->comment,
                        'rated_at' => $sj->jobRating->rated_at->toIso8601String(),
                        'provider_reply' => $reply?->reply,
                        'provider_replied_at' => $reply?->replied_at?->toIso8601String(),
                    ];
                }
                if ($sj->jobRating && $sj->jobRating->skipped_at) {
                    $supplier['rating_skipped'] = true;
                }
                if ($sj->renterRating && $sj->renterRating->rated_at) {
                    $rr = $sj->renterRating;
                    $supplier['provider_rating_of_renter'] = [
                        'rating' => (int) $rr->rating,
                        'comment' => $rr->comment,
                        'rated_at' => $rr->rated_at->toIso8601String(),
                    ];
                } else {
                    $supplier['provider_rating_of_renter'] = null;
                }
                return $supplier;
            })->values();

            $payload = [
                'id' => $job->id,
                'name' => $job->name,
                'from_date' => $job->from_date,
                'to_date' => $job->to_date,
                'delivery_address' => $job->delivery_address,
                'shipping_method' => $job->shipping_method ?? RentalShippingMethods::default(),
                'shipping_method_label' => RentalShippingMethods::label($job->shipping_method),
                'status' => $job->status,
                'suppliers' => $suppliers,
            ];

            // Legacy root job_rating: only when exactly one supplier and that supplier has a rating
            if ($job->supplyJobs->count() === 1) {
                $sj = $job->supplyJobs->first();
                if ($sj->jobRating && $sj->jobRating->rated_at) {
                    $reply = $sj->ratingReply;
                    $payload['job_rating'] = [
                        'rating' => (int) $sj->jobRating->rating,
                        'comment' => $sj->jobRating->comment,
                        'rated_at' => $sj->jobRating->rated_at->toIso8601String(),
                        'provider_reply' => $reply?->reply,
                        'provider_replied_at' => $reply?->replied_at?->toIso8601String(),
                    ];
                }
            }

            return response()->json([
                'success' => true,
                'data' => $payload,
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Rental job not found.'
            ], 404);
        } catch (\Throwable $e) {
            report($e);
            return response()->json([
                'success' => false,
                'message' => 'Failed to load rental job',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal Server Error',
            ], 500);
        }
    }

    /**
     * SUPPLIER DETAILS: Get detailed supplier information for a specific supply job.
     * Returns only the products offered by this supplier, with requested vs supplied quantities, pricing, and latest offer.
     * All users in the same company can view supplier details for rental jobs created by any user in that company.
     */
    public function supplierDetails(Request $request, int $rentalJobId, int $supplyJobId)
    {
        $user = auth('api')->user();

        try {
            // 1. Verify rental job exists and user has access (check by company, not individual user)
            $rentalJob = RentalJob::with('user:id,company_id')
                ->select(['id', 'user_id'])
                ->findOrFail($rentalJobId);

            // Security: only users from the same company or admin can view
            $jobCreatorCompanyId = $rentalJob->user->company_id ?? null;
            if ($jobCreatorCompanyId !== $user->company_id && !$user->is_admin) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized to view this rental job.'
                ], 403);
            }

            // 2. Load supply job with provider, products, offers
            $supplyJob = SupplyJob::with([
                'providerCompany:id,name,currency_id',
                'providerCompany.currency:id,name,code,symbol',
                'products.product' => function ($q) {
                    $q->select('id', 'model', 'brand_id')
                        ->with('brand:id,name');
                },
                'offers' => function ($q) {
                    $q->select('id', 'supply_job_id', 'version', 'total_price', 'status')
                        ->orderByDesc('version');
                },
            ])
                ->where('id', $supplyJobId)
                ->where('rental_job_id', $rentalJobId)
                ->firstOrFail();

            // 3. Fetch requested quantities from rental job products
            $requestedQuantities = RentalJobProduct::where('rental_job_id', $rentalJobId)
                ->pluck('requested_quantity', 'product_id');

            // 4. Build equipment details (only supplier’s products)
            $equipmentDetails = $supplyJob->products->map(function ($supplyProduct) use ($requestedQuantities) {
                $brand = $supplyProduct->product->brand->name ?? '';
                $productName = $supplyProduct->product->model ?? '';

                return [
                    'product_id' => $supplyProduct->product_id,
                    'equipment_name' => trim($brand . ' - ' . $productName, ' -'),
                    'required_quantity' => (int) ($requestedQuantities[$supplyProduct->product_id] ?? 0),
                    'can_supply' => (int) ($supplyProduct->offered_quantity ?? 0),
                    'price_per_unit' => $supplyProduct->price_per_unit !== null ? (float) $supplyProduct->price_per_unit : null,
                ];
            })->values();

            // 5. Get latest offer (if exists)
            $latestOffer = JobOffer::where('rental_job_id', $rentalJobId)
                ->where('supply_job_id', $supplyJob->id)
                ->orderByDesc('version')
                ->first();
            $loggedInCompany = $user->company_id;

            // Default
            $canSendOffer = true;
            $canCancel = true;
            $canHandshake = true;

            if ($latestOffer) {

                if (in_array($latestOffer->status, ['accepted', 'cancelled'])) {
                    $canSendOffer = false;
                    $canCancel = false;
                    $canHandshake = false;
                } else {
                    if ($latestOffer->sender_company_id == $loggedInCompany) {
                        // User sent the last offer → cannot send new one
                        $canSendOffer = false;
                        $canCancel = false;
                        $canHandshake = false;
                    } else {
                        // Other company sent last offer → user can reply
                        $canSendOffer = true;
                        $canCancel = true;
                        $canHandshake = true;
                    }
                }
            }


            // 6. Build response payload
            $provider = $supplyJob->providerCompany;
            $currency = $provider?->currency;

            $payload = [
                'supply_job_id' => $supplyJob->id,
                'rental_job_id' => $supplyJob->rental_job_id,
                'company_id' => $provider->id,
                'company_name' => $provider->name,
                'currency' => $currency ? [
                    'id' => $currency->id,
                    'name' => $currency->name,
                    'code' => $currency->code,
                    'symbol' => $currency->symbol,
                ] : null,
                'status' => $this->effectiveSupplyJobStatus($supplyJob),
                'rating_skipped' => $supplyJob->jobRating && $supplyJob->jobRating->skipped_at,
                'equipment_details' => $equipmentDetails,
                'latest_offer' => $latestOffer ? [
                    'id' => $latestOffer->id,
                    'version' => (int) $latestOffer->version,
                    'total_price' => (string) $latestOffer->total_price,
                    'status' => $latestOffer->status,
                    'sender_company_id' => $latestOffer->sender_company_id,
                    'receiver_company_id' => $latestOffer->receiver_company_id,
                ] : null,
                'negotiation_controls' => [
                    'can_handshake' => $canHandshake,
                    'can_send_offer' => $canSendOffer,
                    'can_cancel_negotiation' => $canCancel,
                ],
                'comments_endpoint' => "/api/supply-jobs/{$supplyJob->id}/comments",
            ];
            return response()->json([
                'success' => true,
                'data' => $payload,
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            \Log::warning("Supplier details not found", [
                'rental_job_id' => $rentalJobId,
                'supply_job_id' => $supplyJobId,
                'user_id' => $user->id,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Supply job not found.'
            ], 404);
        } catch (\Throwable $e) {
            \Log::error("Failed to load supplier details", [
                'error' => $e->getMessage(),
                'rental_job_id' => $rentalJobId,
                'supply_job_id' => $supplyJobId,
                'user_id' => $user->id,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to load supplier details.',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal Server Error',
            ], 500);
        }
    }

    /**
     * Return effective supply job status for display.
     * "rated" is only shown when the renter has actually submitted a rating or skipped (job_rating has rated_at or skipped_at).
     * Fixes inconsistency where status could be "rated" in DB but no rating was given.
     */
    private function effectiveSupplyJobStatus(SupplyJob $supplyJob): string
    {
        if (
            $supplyJob->status === 'cancelled'
            && $supplyJob->cancelledByUser
            && (bool) $supplyJob->cancelledByUser->is_admin
        ) {
            return 'admin_cancelled';
        }

        $status = $supplyJob->status;
        $jobRating = $supplyJob->jobRating;

        if ($status !== 'rated') {
            return $status;
        }
        if (!$jobRating) {
            return 'completed_pending_rating';
        }
        if ($jobRating->rated_at || $jobRating->skipped_at) {
            return 'rated';
        }
        return 'completed_pending_rating';
    }
}
