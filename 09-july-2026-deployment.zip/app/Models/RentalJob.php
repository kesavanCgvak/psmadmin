<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\RentalJobProduct;
use App\Models\SupplyJob;
use App\Models\RentalJobComment;
use App\Models\User;


class RentalJob extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'name',
        'from_date',
        'to_date',
        'delivery_address',
        'shipping_method',
        'offer_requirements',
        'global_message',
        'status',
        'flex_sales_quote_id',
        'flex_sales_quote_number',
        'flex_sync_status',
        'cancelled_by',
        'notes',
    ];

    protected $casts = [
        'from_date' => 'date',
        'to_date' => 'date',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function products()
    {
        return $this->hasMany(RentalJobProduct::class);
    }

    public function supplyJobs()
    {
        return $this->hasMany(SupplyJob::class);
    }

    public function comments()
    {
        return $this->hasMany(RentalJobComment::class);
    }

    public function offers()
    {
        return $this->hasMany(JobOffer::class, 'rental_job_id');
    }

    /** One rating per supply job (per provider). */
    public function jobRatings()
    {
        return $this->hasMany(JobRating::class, 'rental_job_id');
    }

    /** Legacy: first rating when only one supplier (for backward compatibility). */
    public function jobRating()
    {
        return $this->hasOne(JobRating::class, 'rental_job_id');
    }

    public function getTotalRequestedQuantityAttribute()
    {
        return $this->products->sum('requested_quantity');
    }

    // public function supplyOffers()
    // {
    //     return $this->hasMany(SupplyJobOffer::class, 'rental_job_id');
    // }

    public function requesterCompany()
    {
        return $this->belongsTo(Company::class, 'requester_company_id');
    }

    public function flexIntegrationLogs()
    {
        return $this->hasMany(FlexIntegrationLog::class, 'rental_request_id');
    }

    public function rentalRequestProviderQuotes()
    {
        return $this->hasMany(RentalRequestProviderQuote::class, 'rental_request_id');
    }

}

