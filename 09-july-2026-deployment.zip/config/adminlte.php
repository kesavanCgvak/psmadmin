<?php

use JeroenNoten\LaravelAdminLte\Menu\Filters\ActiveFilter;
use JeroenNoten\LaravelAdminLte\Menu\Filters\ClassesFilter;
use JeroenNoten\LaravelAdminLte\Menu\Filters\DataFilter;
use JeroenNoten\LaravelAdminLte\Menu\Filters\GateFilter;
use JeroenNoten\LaravelAdminLte\Menu\Filters\HrefFilter;
use JeroenNoten\LaravelAdminLte\Menu\Filters\LangFilter;
use JeroenNoten\LaravelAdminLte\Menu\Filters\SearchFilter;

return [

    /*
    |--------------------------------------------------------------------------
    | Title
    |--------------------------------------------------------------------------
    |
    | Here you can change the default title of your admin panel.
    |
    | For detailed instructions you can look the title section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'title' => 'PSM Admin Panel',
    'title_prefix' => '',
    'title_postfix' => ' - Equipment Rental Platform',

    /*
    |--------------------------------------------------------------------------
    | Favicon
    |--------------------------------------------------------------------------
    |
    | Here you can activate the favicon.
    |
    | For detailed instructions you can look the favicon section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'use_ico_only' => false,
    'use_full_favicon' => false,

    /*
    |--------------------------------------------------------------------------
    | Google Fonts
    |--------------------------------------------------------------------------
    |
    | Here you can allow or not the use of external google fonts. Disabling the
    | google fonts may be useful if your admin panel internet access is
    | restricted somehow.
    |
    | For detailed instructions you can look the google fonts section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'google_fonts' => [
        'allowed' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | Admin Panel Logo
    |--------------------------------------------------------------------------
    |
    | Here you can change the logo of your admin panel.
    |
    | For detailed instructions you can look the logo section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'logo' => '<b>PSM</b> Admin',
    'logo_img' => 'images/logo-white.png',
    'logo_img_class' => 'brand-image',
    'logo_img_xl' => null,
    'logo_img_xl_class' => 'brand-image-xs',
    'logo_img_alt' => 'PSM Logo',

    /*
    |--------------------------------------------------------------------------
    | Authentication Logo
    |--------------------------------------------------------------------------
    |
    | Here you can setup an alternative logo to use on your login and register
    | screens. When disabled, the admin panel logo will be used instead.
    |
    | For detailed instructions you can look the auth logo section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'auth_logo' => [
        'enabled' => true,
        'img' => [
            'path' => 'images/logo.png',
            'alt' => 'PSM Admin',
            'class' => '',
            'width' => 80,
            'height' => 80,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Preloader Animation
    |--------------------------------------------------------------------------
    |
    | Here you can change the preloader animation configuration. Currently, two
    | modes are supported: 'fullscreen' for a fullscreen preloader animation
    | and 'cwrapper' to attach the preloader animation into the content-wrapper
    | element and avoid overlapping it with the sidebars and the top navbar.
    |
    | For detailed instructions you can look the preloader section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'preloader' => [
        'enabled' => true,
        'mode' => 'fullscreen',
        'img' => [
            'path' => 'vendor/adminlte/dist/img/AdminLTELogo.png',
            'alt' => 'AdminLTE Preloader Image',
            'effect' => 'animation__shake',
            'width' => 60,
            'height' => 60,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | User Menu
    |--------------------------------------------------------------------------
    |
    | Here you can activate and change the user menu.
    |
    | For detailed instructions you can look the user menu section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'usermenu_enabled' => true,
    'usermenu_header' => false,
    'usermenu_header_class' => 'bg-primary',
    'usermenu_image' => false,
    'usermenu_desc' => true,
    'usermenu_profile_url' => true,

    /*
    |--------------------------------------------------------------------------
    | Layout
    |--------------------------------------------------------------------------
    |
    | Here we change the layout of your admin panel.
    |
    | For detailed instructions you can look the layout section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'layout_topnav' => null,
    'layout_boxed' => null,
    'layout_fixed_sidebar' => null,
    'layout_fixed_navbar' => null,
    'layout_fixed_footer' => null,
    'layout_dark_mode' => null,

    /*
    |--------------------------------------------------------------------------
    | Authentication Views Classes
    |--------------------------------------------------------------------------
    |
    | Here you can change the look and behavior of the authentication views.
    |
    | For detailed instructions you can look the auth classes section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'classes_auth_card' => 'card-outline card-primary',
    'classes_auth_header' => '',
    'classes_auth_body' => '',
    'classes_auth_footer' => '',
    'classes_auth_icon' => '',
    'classes_auth_btn' => 'btn-flat btn-primary',

    /*
    |--------------------------------------------------------------------------
    | Admin Panel Classes
    |--------------------------------------------------------------------------
    |
    | Here you can change the look and behavior of the admin panel.
    |
    | For detailed instructions you can look the admin panel classes here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'classes_body' => '',
    'classes_brand' => '',
    'classes_brand_text' => '',
    'classes_content_wrapper' => '',
    'classes_content_header' => '',
    'classes_content' => '',
    'classes_sidebar' => 'sidebar-dark-primary elevation-4',
    'classes_sidebar_nav' => '',
    'classes_topnav' => 'navbar-white navbar-light',
    'classes_topnav_nav' => 'navbar-expand',
    'classes_topnav_container' => 'container',

    /*
    |--------------------------------------------------------------------------
    | Sidebar
    |--------------------------------------------------------------------------
    |
    | Here we can modify the sidebar of the admin panel.
    |
    | For detailed instructions you can look the sidebar section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'sidebar_mini' => 'lg',
    'sidebar_collapse' => false,
    'sidebar_collapse_auto_size' => false,
    'sidebar_collapse_remember' => false,
    'sidebar_collapse_remember_no_transition' => true,
    'sidebar_scrollbar_theme' => 'os-theme-light',
    'sidebar_scrollbar_auto_hide' => 'l',
    'sidebar_nav_accordion' => true,
    'sidebar_nav_animation_speed' => 300,

    /*
    |--------------------------------------------------------------------------
    | Control Sidebar (Right Sidebar)
    |--------------------------------------------------------------------------
    |
    | Here we can modify the right sidebar aka control sidebar of the admin panel.
    |
    | For detailed instructions you can look the right sidebar section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Layout-and-Styling-Configuration
    |
    */

    'right_sidebar' => false,
    'right_sidebar_icon' => 'fas fa-cogs',
    'right_sidebar_theme' => 'dark',
    'right_sidebar_slide' => true,
    'right_sidebar_push' => true,
    'right_sidebar_scrollbar_theme' => 'os-theme-light',
    'right_sidebar_scrollbar_auto_hide' => 'l',

    /*
    |--------------------------------------------------------------------------
    | URLs
    |--------------------------------------------------------------------------
    |
    | Here we can modify the url settings of the admin panel.
    |
    | For detailed instructions you can look the urls section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Basic-Configuration
    |
    */

    'use_route_url' => false,
    'dashboard_url' => 'dashboard',
    'logout_url' => 'logout',
    'login_url' => 'login',
    'register_url' => null, // Disable register link
    'password_reset_url' => null, // Disable forgot password link
    'password_email_url' => 'password.email',
    'profile_url' => 'profile',
    'disable_darkmode_routes' => false,

    /*
    |--------------------------------------------------------------------------
    | Laravel Asset Bundling
    |--------------------------------------------------------------------------
    |
    | Here we can enable the Laravel Asset Bundling option for the admin panel.
    | Currently, the next modes are supported: 'mix', 'vite' and 'vite_js_only'.
    | When using 'vite_js_only', it's expected that your CSS is imported using
    | JavaScript. Typically, in your application's 'resources/js/app.js' file.
    | If you are not using any of these, leave it as 'false'.
    |
    | For detailed instructions you can look the asset bundling section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Other-Configuration
    |
    */

    'laravel_asset_bundling' => false,
    'laravel_css_path' => 'css/app.css',
    'laravel_js_path' => 'js/app.js',

    /*
    |--------------------------------------------------------------------------
    | Menu Items
    |--------------------------------------------------------------------------
    |
    | Here we can modify the sidebar/top navigation of the admin panel.
    |
    | For detailed instructions you can look here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Menu-Configuration
    |
    */

    'menu' => [
        // Navbar items:
        [
            'type' => 'fullscreen-widget',
            'topnav_right' => true,
        ],
        // [
        //     'type' => 'navbar-notification',
        //     'id' => 'my-notification',
        //     'icon' => 'fas fa-bell',
        //     'icon_color' => 'warning',
        //     'label' => 0,
        //     'label_color' => 'danger',
        //     'url' => '#',
        //     'topnav_right' => true,
        // ],

        // Sidebar items:
        [
            'type' => 'sidebar-menu-search',
            'text' => 'search',
        ],
        ['header' => 'MAIN NAVIGATION'],
        [
            'text' => 'Dashboard',
            'route' => 'dashboard',
            'icon' => 'fas fa-fw fa-tachometer-alt',
            'icon_color' => 'primary',
        ],
        ['header' => 'GEOGRAPHY MANAGEMENT'],
        [
            'text' => 'Regions',
            'route' => 'regions.index',
            'icon' => 'fas fa-fw fa-globe-americas',
            'icon_color' => 'primary',
        ],
        [
            'text' => 'Countries',
            'route' => 'countries.index',
            'icon' => 'fas fa-fw fa-flag',
            'icon_color' => 'success',
        ],
        [
            'text' => 'States / Provinces',
            'route' => 'states.index',
            'icon' => 'fas fa-fw fa-map-marked-alt',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Cities',
            'route' => 'cities.index',
            'icon' => 'fas fa-fw fa-city',
            'icon_color' => 'warning',
        ],
        ['header' => 'PRODUCT CATALOG MANAGEMENT'],
        [
            'text' => 'Categories',
            'route' => 'admin.categories.index',
            'icon' => 'fas fa-fw fa-th-large',
            'icon_color' => 'primary',
        ],
        [
            'text' => 'Sub-Categories',
            'route' => 'admin.subcategories.index',
            'icon' => 'fas fa-fw fa-th',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Brands',
            'route' => 'admin.brands.index',
            'icon' => 'fas fa-fw fa-copyright',
            'icon_color' => 'success',
        ],
        [
            'text' => 'Products',
            'route' => 'admin.products.index',
            'icon' => 'fas fa-fw fa-cubes',
            'icon_color' => 'warning',
        ],
        ['header' => 'INVENTORY MANAGEMENT'],
        [
            'text' => 'AI Specification Reviews',
            'route' => 'admin.ai-specifications.index',
            'icon' => 'fas fa-fw fa-robot',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Products Missing Specifications',
            'route' => 'admin.products-missing-specifications.index',
            'icon' => 'fas fa-fw fa-ruler-combined',
            'icon_color' => 'warning',
        ],
        [
            'text' => 'Rejected AI Products',
            'route' => 'admin.ai-rejections.index',
            'icon' => 'fas fa-fw fa-ban',
            'icon_color' => 'danger',
        ],
        [
            'text' => 'AI Specification Audit Logs',
            'route' => 'admin.ai-specifications.audit-logs',
            'icon' => 'fas fa-fw fa-history',
            'icon_color' => 'secondary',
        ],
        ['header' => 'COMPANY MANAGEMENT'],
        [
            'text' => 'Companies',
            'route' => 'admin.companies.index',
            'icon' => 'fas fa-fw fa-building',
            'icon_color' => 'primary',
        ],
        [
            'text' => 'Logo Management',
            'route' => 'admin.logo-management.index',
            'icon' => 'fas fa-fw fa-image',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Currencies',
            'route' => 'admin.currencies.index',
            'icon' => 'fas fa-fw fa-dollar-sign',
            'icon_color' => 'success',
        ],
        [
            'text' => 'Date Formats',
            'route' => 'admin.date-formats.index',
            'icon' => 'fas fa-fw fa-calendar-alt',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Pricing Schemes',
            'route' => 'admin.pricing-schemes.index',
            'icon' => 'fas fa-fw fa-tags',
            'icon_color' => 'warning',
        ],
        [
            'text' => 'Rental Software',
            'route' => 'admin.rental-software.index',
            'icon' => 'fas fa-fw fa-laptop-code',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Rental Software Company Logos',
            'route' => 'admin.rental-software-company-logos.index',
            'icon' => 'fas fa-fw fa-images',
            'icon_color' => 'primary',
        ],
        [
            'text' => 'All Equipment',
            'route' => 'admin.equipment.index',
            'icon' => 'fas fa-fw fa-boxes',
            'icon_color' => 'warning',
        ],
        ['header' => 'USER MANAGEMENT'],
        [
            'text' => 'All Users',
            'route' => 'admin.users.index',
            'icon' => 'fas fa-fw fa-users',
            'icon_color' => 'primary',
        ],
        [
            'text' => 'Super Admin Users',
            'route' => 'admin.admin-users.index',
            'icon' => 'fas fa-fw fa-user-shield',
            'icon_color' => 'danger',
        ],
        ['header' => 'JOB MANAGEMENT'],
        [
            'text' => 'Rental Jobs',
            'route' => 'admin.rental-jobs.index',
            'icon' => 'fas fa-fw fa-briefcase',
            'icon_color' => 'primary',
        ],
        [
            'text' => 'Supply Jobs',
            'route' => 'admin.supply-jobs.index',
            'icon' => 'fas fa-fw fa-truck',
            'icon_color' => 'success',
        ],
        [
            'text' => 'Job Ratings',
            'route' => 'admin.job-ratings.index',
            'icon' => 'fas fa-fw fa-star',
            'icon_color' => 'warning',
        ],
        ['header' => 'SUPPORT MANAGEMENT'],
        [
            'text' => 'Issue Types',
            'route' => 'admin.issue-types.index',
            'icon' => 'fas fa-fw fa-question-circle',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Contact Sales',
            'route' => 'admin.contact-sales.index',
            'icon' => 'fas fa-fw fa-handshake',
            'icon_color' => 'success',
        ],
        ['header' => 'SYSTEM SETTINGS'],
        [
            'text' => 'Payment Settings',
            'route' => 'admin.payment-settings.index',
            'icon' => 'fas fa-fw fa-credit-card',
            'icon_color' => 'success',
        ],
        [
            'text' => 'CMS Pages',
            'route' => 'admin.cms-pages.index',
            'icon' => 'fas fa-fw fa-file-alt',
            'icon_color' => 'primary',
        ],
        [
            'text' => 'Terms and Conditions',
            'route' => 'admin.terms-and-conditions.index',
            'icon' => 'fas fa-fw fa-file-contract',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Email Templates',
            'route' => 'admin.email-templates.index',
            'icon' => 'fas fa-fw fa-envelope',
            'icon_color' => 'primary',
        ],
        [
            'text' => 'Email Logs',
            'route' => 'admin.email-logs.index',
            'icon' => 'fas fa-fw fa-inbox',
            'icon_color' => 'info',
        ],
        [
            'text' => 'Communication',
            'icon' => 'fas fa-fw fa-comments',
            'icon_color' => 'info',
            'submenu' => [
                [
                    'text' => 'SMS Logs',
                    'route' => 'admin.sms-logs.index',
                    'icon' => 'fas fa-fw fa-sms',
                ],
            ],
        ],
        [
            'text' => 'User Login Activity',
            'route' => 'admin.user-auth-events.index',
            'icon' => 'fas fa-fw fa-user-clock',
            'icon_color' => 'secondary',
        ],
        [
            'text' => 'User Restrictions',
            'route' => 'admin.user-restrictions.index',
            'icon' => 'fas fa-fw fa-users-cog',
            'icon_color' => 'warning',
        ],
        [
            'text' => 'Measurement Units',
            'icon' => 'fas fa-fw fa-ruler-combined',
            'icon_color' => 'info',
            'submenu' => [
                [
                    'text' => 'Linear Units',
                    'route' => 'admin.linear-units.index',
                    'icon' => 'fas fa-fw fa-ruler-horizontal',
                ],
                [
                    'text' => 'Weight Units',
                    'route' => 'admin.weight-units.index',
                    'icon' => 'fas fa-fw fa-weight-hanging',
                ],
            ],
        ],
        [
            'text' => 'Subscriptions',
            'route' => 'admin.subscriptions.index',
            'icon' => 'fas fa-fw fa-receipt',
            'icon_color' => 'primary',
        ],
        ['header' => 'ACCOUNT SETTINGS'],
        [
            'text' => 'My Profile',
            'route' => 'profile.edit',
            'icon' => 'fas fa-fw fa-user',
            'icon_color' => 'primary',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Menu Filters
    |--------------------------------------------------------------------------
    |
    | Here we can modify the menu filters of the admin panel.
    |
    | For detailed instructions you can look the menu filters section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Menu-Configuration
    |
    */

    'filters' => [
        GateFilter::class,
        HrefFilter::class,
        SearchFilter::class,
        ActiveFilter::class,
        ClassesFilter::class,
        LangFilter::class,
        DataFilter::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Plugins Initialization
    |--------------------------------------------------------------------------
    |
    | Here we can modify the plugins used inside the admin panel.
    |
    | For detailed instructions you can look the plugins section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Plugins-Configuration
    |
    */

    'plugins' => [
        'Datatables' => [
            'active' => true,
            'files' => [
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js',
                ],
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js',
                ],
                [
                    'type' => 'css',
                    'asset' => false,
                    'location' => '//cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css',
                ],
                [
                    'type' => 'css',
                    'asset' => true,
                    'location' => 'css/datatables-adminlte.css',
                ],
                [
                    'type' => 'js',
                    'asset' => true,
                    'location' => 'js/datatables-adminlte.js',
                ],
            ],
        ],
        'Select2' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js',
                ],
                [
                    'type' => 'css',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.css',
                ],
            ],
        ],
        'Chartjs' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.bundle.min.js',
                ],
            ],
        ],
        'Sweetalert2' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdn.jsdelivr.net/npm/sweetalert2@8',
                ],
            ],
        ],
        'Pace' => [
            'active' => false,
            'files' => [
                [
                    'type' => 'css',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/themes/blue/pace-theme-center-radar.min.css',
                ],
                [
                    'type' => 'js',
                    'asset' => false,
                    'location' => '//cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js',
                ],
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | IFrame
    |--------------------------------------------------------------------------
    |
    | Here we change the IFrame mode configuration. Note these changes will
    | only apply to the view that extends and enable the IFrame mode.
    |
    | For detailed instructions you can look the iframe mode section here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/IFrame-Mode-Configuration
    |
    */

    'iframe' => [
        'default_tab' => [
            'url' => null,
            'title' => null,
        ],
        'buttons' => [
            'close' => true,
            'close_all' => true,
            'close_all_other' => true,
            'scroll_left' => true,
            'scroll_right' => true,
            'fullscreen' => true,
        ],
        'options' => [
            'loading_screen' => 1000,
            'auto_show_new_tab' => true,
            'use_navbar_items' => true,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Livewire
    |--------------------------------------------------------------------------
    |
    | Here we can enable the Livewire support.
    |
    | For detailed instructions you can look the livewire here:
    | https://github.com/jeroennoten/Laravel-AdminLTE/wiki/Other-Configuration
    |
    */

    'livewire' => false,
];
