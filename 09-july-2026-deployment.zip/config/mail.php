<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Mailer
    |--------------------------------------------------------------------------
    |
    | This option controls the default mailer that is used to send all email
    | messages unless another mailer is explicitly specified when sending
    | the message. All additional mailers can be configured within the
    | "mailers" array. Examples of each type of mailer are provided.
    |
    */

    'default' => env('MAIL_MAILER', 'log'),

    /*
    |--------------------------------------------------------------------------
    | Mailer Configurations
    |--------------------------------------------------------------------------
    |
    | Here you may configure all of the mailers used by your application plus
    | their respective settings. Several examples have been configured for
    | you and you are free to add your own as your application requires.
    |
    | Laravel supports a variety of mail "transport" drivers that can be used
    | when delivering an email. You may specify which one you're using for
    | your mailers below. You may also add additional mailers if needed.
    |
    | Supported: "smtp", "sendmail", "mailgun", "ses", "ses-v2",
    |            "postmark", "resend", "log", "array",
    |            "failover", "roundrobin"
    |
    */

    'mailers' => [

        'smtp' => [
            'transport' => 'smtp',
            'scheme' => env('MAIL_SCHEME'),
            'url' => env('MAIL_URL'),
            'host' => env('MAIL_HOST', '127.0.0.1'),
            'port' => env('MAIL_PORT', 2525),
            'username' => env('MAIL_USERNAME'),
            'password' => env('MAIL_PASSWORD'),
            'timeout' => null,
            'local_domain' => env('MAIL_EHLO_DOMAIN', parse_url((string) env('APP_URL', 'http://localhost'), PHP_URL_HOST)),
        ],

        'ses' => [
            'transport' => 'ses',
        ],

        'postmark' => [
            'transport' => 'postmark',
            // 'message_stream_id' => env('POSTMARK_MESSAGE_STREAM_ID'),
            // 'client' => [
            //     'timeout' => 5,
            // ],
        ],

        'resend' => [
            'transport' => 'resend',
        ],

        'sendmail' => [
            'transport' => 'sendmail',
            'path' => env('MAIL_SENDMAIL_PATH', '/usr/sbin/sendmail -bs -i'),
        ],

        'log' => [
            'transport' => 'log',
            'channel' => env('MAIL_LOG_CHANNEL'),
        ],

        'array' => [
            'transport' => 'array',
        ],

        'failover' => [
            'transport' => 'failover',
            'mailers' => [
                'smtp',
                'log',
            ],
            'retry_after' => 60,
        ],

        'roundrobin' => [
            'transport' => 'roundrobin',
            'mailers' => [
                'ses',
                'postmark',
            ],
            'retry_after' => 60,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Global "From" Address
    |--------------------------------------------------------------------------
    |
    | You may wish for all emails sent by your application to be sent from
    | the same address. Here you may specify a name and address that is
    | used globally for all emails that are sent by your application.
    |
    */

    'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'noreply@prosubmarket.com'),
        'name' => env('MAIL_FROM_NAME', 'Pro Subrental Marketplace'),
        'to_address' => env('MAIL_TO_ADDRESS', 'k7.cgvak@gmail.com'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Global "To" Address
    |--------------------------------------------------------------------------
    | You may wish for all emails sent by your application to be sent to
    | the same address. Here you may specify a name and address that is
    | used globally for all emails that are sent by your application.
    |
    */
    'to' => [
        'name' => env('MAIL_FROM_NAME', 'Pro Subrental Marketplace'),
        'addresses' => explode(',', env('MAIL_TO_NOTIFY_NEW_REGISTRATION', '')),
    ],

    'admin' => [
        'name' => env('MAIL_FROM_NAME', 'PSM Admin'),
        'address' => env('MAIL_TO_ADMIN', 'noreply@prosubmarket.com'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Open API / Provider API key access request (POST .../request-access)
    |--------------------------------------------------------------------------
    | Comma-separated admin inbox(es) for provider Open API access requests.
    | Falls back to mail.to.addresses, then mail.admin.address, then from address.
    */
    'open_api_access_request' => [
        'addresses' => array_values(array_filter(array_map(
            static fn (string $email): string => trim($email),
            explode(',', (string) env('MAIL_TO_OPEN_API_ACCESS_REQUEST', ''))
        ))),
    ],

    /*
    |--------------------------------------------------------------------------
    | Support Inbox Email
    |--------------------------------------------------------------------------
    |
    | Email address where support requests should be sent.
    |
    */
    'support_inbox' => env('SUPPORT_INBOX_EMAIL', 'support@secondwarehouse.com'),

    /** Sales Inbox Email   */

    'sales_inbox' => env('SALES_INBOX_EMAIL', 'contact@secondwarehouse.com'),

    /*
    |--------------------------------------------------------------------------
    | Logo URL for emails
    |--------------------------------------------------------------------------
    | Use a full, publicly accessible URL (e.g. https://yourdomain.com/images/logo-white.png)
    | so the logo loads in email clients. If not set, falls back to asset() which uses APP_URL;
    | local/dev APP_URL will show a broken image when the email is opened elsewhere.
    */
    'logo_url' => env('EMAIL_LOGO_URL', null),

];
