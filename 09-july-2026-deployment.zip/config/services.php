<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'resend' => [
        'key' => env('RESEND_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'stripe' => [
        'key' => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
        'webhook_secret' => env('STRIPE_WEBHOOK_SECRET'),
    ],

    // Active SMS provider used for supplier notifications: 'twilio' or 'textmagic'.
    'sms' => [
        'driver' => env('SMS_DRIVER', 'twilio'),
    ],

    'twilio' => [
        'sid' => env('TWILIO_SID'),
        'token' => env('TWILIO_AUTH_TOKEN'),
        'from' => env('TWILIO_FROM'),
    ],

    'textmagic' => [
        'username' => env('TEXTMAGIC_USERNAME'),
        'key' => env('TEXTMAGIC_API_KEY'),
    ],

    'rentman' => [
        'base_url' => env('RENTMAN_API_BASE_URL', 'https://api.rentman.net'),
        'default_linear_unit' => env('RENTMAN_DEFAULT_LINEAR_UNIT', 'inches'),
        'default_weight_unit' => env('RENTMAN_DEFAULT_WEIGHT_UNIT', 'lbs'),
        'default_linear_unit_id' => env('RENTMAN_DEFAULT_LINEAR_UNIT_ID'),
        'default_weight_unit_id' => env('RENTMAN_DEFAULT_WEIGHT_UNIT_ID'),
    ],

];
