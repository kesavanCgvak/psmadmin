<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'logo',
        'description',
        'date_format',
        'pricing_scheme',
        'address_line_1',
        'address_line_2',
        'postal_code',
        'default_contact_id',
        'rental_software_id',
        'currency_id',
        'region_id',
        'country_id',
        'city_id',
        'longitude',
        'latitude',
        'search_priority',
        'rating',
        'image1',
        'image2',
        'image3',
        'rental_software',
    ];


    public function users()
    {
        return $this->hasMany(User::class);
    }
}

