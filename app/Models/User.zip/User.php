<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use App\Models\Company;
use App\Models\UserProfile;

class User extends Authenticatable implements JWTSubject
{
    use Notifiable;

    protected $fillable = [
        'account_type',
        'username',
        'name',
        'email',
        'password',
        'company_id',
        'is_company_default_contact',
        'is_admin',
        'role',
        'stripe_customer_id',
        'is_blocked',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key-value array, containing any custom claims to be added to JWT.
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function profile()
    {
        return $this->hasOne(UserProfile::class);
    }

}
